function Lower_Bound_find_q(M, N)
% LOWER_BOUND_FIND_Q Compute auxiliary delivery rates for the AoI lower bound.
%
% Inputs:
%   M  Number of users.
%   N  Maximum number of scheduled users per slot.
%
% Global configuration:
%   probabilityS, probabilityD  Per-user link success probabilities.
%   alpha, arrival             Per-user AoI weights and arrival rates.
%
% Output:
%   optQ  Global M-by-1 vector consumed by the experiment's bound formula.
%
% The rate caps are min(arrival, probabilityS.*probabilityD). If these
% caps exceed the resource budget sum(q_i/p_i) <= N, a threshold is found
% using 200 bisection steps.

global probabilityS probabilityD alpha arrival optQ

iterations = 200; % Number of iterations for the binary search

% Initialize probability, alpha, and arrival arrays
p = zeros(M, 1);
probability = p + probabilityS .* probabilityD; % Ensure "probability" has the correct size

A = zeros(M, 1);
A = A + alpha; % Ensure "alpha" has the correct size

Arr = zeros(M, 1);
Arr = Arr + arrival; % Ensure "arrival" has the correct size
% Cap delivery rates by both arrivals and end-to-end reliability.
Arr = min(Arr, probability); % Limit arrival to the probability

% Initialize optQ
optQ = zeros(M, 1);

% Use the rate caps directly when they meet the resource budget.
if sum(Arr ./ probability) <= N
    for node = 1:M
        optQ(node) = Arr(node);
    end
else
    % Compute the reference threshold and unconstrained rate vector
    Gamma_star = (sum(sqrt(A ./ probability)))^2 / (2 * M * N^2);
    gamma = sqrt(A .* probability ./ (2 * M * Gamma_star));
    
    % Calculate GammaI and initialize max and min Gamma
    GammaI = A .* probability ./ (2 * M * (Arr.^2));
    maxGamma = max(GammaI);
    minGamma = 0;

    % Bisect the threshold using the induced scheduling resource demand.
    for count = 1:iterations
        Gamma_aux = (maxGamma + minGamma) / 2;
        Q_aux = min(Arr, sqrt(A .* probability ./ (2 * M * Gamma_aux)));
        S = sum(Q_aux ./ probability);
        if S <= N
            maxGamma = Gamma_aux;
        else
            minGamma = Gamma_aux;
        end
    end

    % Compute capped delivery rates using the final threshold and scheduling capacity.
    optQ = min(Arr, sqrt(A .* probability * N^2 ./ (2 * M * maxGamma)));
end
end
