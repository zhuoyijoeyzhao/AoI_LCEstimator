function arrival_probabilities = calculate_arrival_probabilities(source_index, K)
% CALCULATE_ARRIVAL_PROBABILITIES Compute discrete renewal arrival probabilities.
%
% Inputs:
%   source_index  Index of the source whose interarrival model is used.
%   K             Simulation horizon in slots.
%
% Output:
%   arrival_probabilities  Row vector of length K-1 for slots 1 through K-1.
%
% Global configuration:
%   arrival, Period, Uniform  Bernoulli rates, periods, and uniform bounds.
%   prob_index               Common model: 1 = Bernoulli, 2 = periodic,
%                            3 = uniform.
%
% The renewal recurrence is u(t) = f_X(t) + sum_{k<t} u(t-k)*f_X(k).
% The local helper generates an interarrival PMF on a support of 1000 slots.
% The geometric distribution is truncated and renormalized on that support.
    global Period arrival Uniform prob_index 
    Arr = arrival;
    per = Period;
   
    % Determine the arrival rate based on the probability index
    if prob_index == 1
        arr = Arr(source_index); % Bernoulli arrival
    elseif prob_index == 2 
        arr = per(source_index); % Periodic arrival
    elseif prob_index == 3 
        arr = Uniform(source_index, :); % Uniform arrival
    end

    slot = 1000;
    timelength = K - 1;
    % Generate PMF based on the probability index and arrival rate
    pmf = generate_pmf(prob_index, slot, arr);

    arrival_probabilities = zeros(1, timelength);

    % Get the length of the PMF
    pmf_length = length(pmf);

    % Calculate the arrival probability for each time slot
    % Apply the renewal recurrence using probabilities from earlier slots.
    for t = 1:timelength
        % Initialize the probability for the current time slot
        probability = 0;
        
        % Iterate to calculate cumulative arrival probability
        % Convolve earlier renewal probabilities with the interarrival PMF.
        for k = 1:pmf_length
            if t - k > 0
                probability = probability + arrival_probabilities(t - k) * pmf(k);
            end
        end

        % Add the base probability for the current time slot
        % Include the probability that the first arrival occurs at slot t.
        if t <= pmf_length
            probability = probability + pmf(t);
        end

        arrival_probabilities(t) = probability;
    end
end

% This function generates the Probability Mass Function (PMF) based on the
% probability index and the arrival rate for different distributions.
function pmf = generate_pmf(prob_index, slot, arr)
    % Generate PMF based on the type of arrival process
    switch prob_index
        case 1 % Bernoulli arrivals: geometric interarrival distribution
            p = arr; % Arrival probability
            pmf = p * (1 - p) .^ (0:slot-1);
            pmf = pmf / sum(pmf); % Normalize
        case 2 % Periodic arrival, constant distribution
            pmf = zeros(1, slot);
            interval = arr; % Period
            if interval <= slot
                pmf(interval) = 1; % Constant arrival time
            end
        case 3 % Uniform arrival
            pmf = zeros(1, slot);
            pmf(arr(1):arr(2)) = 1 / (arr(2) - arr(1) + 1); % Uniformly distributed between arr(1) and arr(2)
        otherwise
            error('Invalid prob_index. Must be 1, 2, or 3.');
    end
end
