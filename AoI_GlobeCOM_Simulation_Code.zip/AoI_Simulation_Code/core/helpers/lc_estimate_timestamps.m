function [gammaU, gammaCurrent] = lc_estimate_timestamps(t, lambda, firstRx, lastRx, previousLastRx, initialGenerationTime)
% LC_ESTIMATE_TIMESTAMPS Evaluate Bernoulli LC timestamp expectations.
%
% Inputs:
%   t                     Current decision slot, a positive integer.
%   lambda                M-by-1 vector of average generation rates in (0,1].
%   firstRx, lastRx       First and last successful reception slots of the
%                         most recently received distinct packet.
%   previousLastRx        Last reception slot of the previous distinct packet;
%                         zero if no earlier distinct packet was received.
%   initialGenerationTime Known source-packet timestamp at initial slot 1;
%                         scalar or M-by-1 vector. Default: 1 (zero source age).
%
% Outputs:
%   gammaU        M-by-1 estimate of the packet timestamp currently at the UE.
%   gammaCurrent  M-by-1 estimate of the most recently received packet timestamp.
%
% For an ordinary observed interval, let a = previousLastRx, b = firstRx,
% c = lastRx, r = 1-lambda, L = b-a, and H = t-c. Packet identity implies at
% least one generation in (a,b] and no generation in (b,c]. The exact iid
% Bernoulli timestamp distributions are
%   qD(phi) = lambda*r^(b-phi)/(1-r^L),             a < phi <= b;
%   qU(phi) = r^H*qD(phi),                         a < phi <= b;
%   qU(phi) = lambda*r^(t-phi),                    c < phi <= t;
% with zero mass elsewhere. Both distributions are normalized. The interval
% (a,b] is conditioned on containing a generation, while (c,t] is unobserved.
%
% The model uses independent Bernoulli generations, independent links, and
% packet-identity observations. For other renewal processes, the estimator
% uses the Bernoulli approximation at the mean generation rate lambda.
% Finite geometric-series identities give O(M) work and temporary storage,
% independent of the observation-window lengths, without storing PMF arrays.
%
% Boundary conventions:
%   * Before any reception, all reception indices are zero. Propagate the
%     known initial packet from slot 1 through the unobserved slots 2:t.
%   * At the first-ever reception (previousLastRx=0), the packet can still
%     be the initial packet. Propagate the initial prior to firstRx without
%     conditioning on a fresh arrival; repeated copies add no further
%     information about that timestamp under independent Bernoulli arrivals.
%   * An empty recent window leaves the received-packet mean unchanged.
%   * A one-slot conditioned window or a unit rate has zero generation lag.
% The initial prior specifies a known packet at slot 1. The simulation
% callers use a default initial source age of zero.
%
% The caller applies the destination recursion and converts timestamps to
% ages. Inputs contain receptions available at the beginning of slot t;
% current-slot reception results are used at the following decision slot.

if nargin < 6
    initialGenerationTime = 1;
end
validateattributes(t, {'numeric'}, {'scalar','real','finite','integer','positive'}, mfilename, 't');
validateattributes(lambda, {'numeric'}, {'vector','real','finite','positive','<=',1}, mfilename, 'lambda');
lambda = lambda(:);
firstRx = firstRx(:);
lastRx = lastRx(:);
previousLastRx = previousLastRx(:);
M = numel(lambda);
if numel(firstRx) ~= M || numel(lastRx) ~= M || numel(previousLastRx) ~= M
    error('LC:StateSize', 'Reception-state vectors must match the arrival-rate vector.');
end
state = [firstRx; lastRx; previousLastRx];
if any(~isfinite(state) | state < 0 | state ~= floor(state))
    error('LC:InvalidState', 'Reception slots must be finite nonnegative integers.');
end
observed = firstRx > 0;
if any(firstRx > lastRx | lastRx > t) || ...
        any(previousLastRx(observed) >= firstRx(observed)) || ...
        any(lastRx(~observed) ~= 0 | previousLastRx(~observed) ~= 0)
    error('LC:InvalidState', 'Reception slots must preserve the order previousLastRx < firstRx <= lastRx <= t.');
end
if isscalar(initialGenerationTime)
    initialGenerationTime = repmat(initialGenerationTime, M, 1);
else
    initialGenerationTime = initialGenerationTime(:);
end
if numel(initialGenerationTime) ~= M || any(~isfinite(initialGenerationTime))
    error('LC:InitialState', 'Initial generation times must be finite and scalar or M-by-1.');
end

% Mean timestamp of the most recently received distinct packet.
gammaCurrent = initialGenerationTime;
ordinary = observed & previousLastRx > 0;
L = firstRx(ordinary) - previousLastRx(ordinary);
gammaCurrent(ordinary) = firstRx(ordinary) - ...
    truncated_geometric_lag(lambda(ordinary), L);

% No earlier observed packet: a first reception is not evidence of a new
% generation after initialization. Use the known initial-packet prior.
firstPacket = observed & previousLastRx == 0;
gammaCurrent(firstPacket) = propagate_timestamp( ...
    initialGenerationTime(firstPacket), ones(sum(firstPacket),1), ...
    firstRx(firstPacket), lambda(firstPacket));

% Propagate through an unobserved Bernoulli window. The old packet survives
% with probability (1-lambda)^H, including when H=1 or lambda is very small.
windowStart = lastRx;
windowStart(~observed) = 1;
gammaU = propagate_timestamp(gammaCurrent, windowStart, ...
    t * ones(M,1), lambda);
end

function meanTimestamp = propagate_timestamp(previousMean, startSlot, endSlot, p)
% PROPAGATE_TIMESTAMP Mix the surviving old packet with the latest new packet.
% The recent-packet mean is conditional on at least one new generation; its
% mixture mass is the unconditional probability 1-(1-p)^H. Weighted timestamp
% means provide stable propagation for small arrival rates.
% expm1 accurately evaluates the recent-arrival probability.
meanTimestamp = previousMean;
H = endSlot - startSlot;
active = H > 0;
logSurvival = H(active) .* log1p(-p(active));
oldMass = exp(logSurvival);
newMass = -expm1(logSurvival);
recentMean = endSlot(active) - truncated_geometric_lag(p(active), H(active));
meanTimestamp(active) = oldMass .* previousMean(active) + newMass .* recentMean;
end

function lag = truncated_geometric_lag(p, n)
% TRUNCATED_GEOMETRIC_LAG E[k] for k=0:n-1 with mass proportional to p*(1-p)^k.
% E[k] = r/p - n*r^n/(1-r^n). A small-argument series evaluates this expectation
% when n*p is small, using x=-log(1-p) and 1/expm1(x)-n/expm1(n*x).
lag = zeros(size(p));
active = n > 1 & p < 1;
x = -log1p(-p(active));
m = n(active);
y = m .* x;
small = y < 0.01;
values = zeros(size(x));
xs = x(small); ys = y(small); ns = m(small);
values(small) = (ns-1)/2 - (ns.*ys-xs)/12 + ...
    (ns.*ys.^3-xs.^3)/720 - (ns.*ys.^5-xs.^5)/30240;
large = ~small;
tail = exp(-y(large));
mass = -expm1(-y(large));
pa = p(active);
values(large) = (1-pa(large))./pa(large) - m(large).*tail./mass;
lag(active) = values;
% Limit only floating-point excursions outside the mathematical support.
lag = max(0, min(n-1, lag));
end
