function randomized_find_optMU(M, N)
% RANDOMIZED_FIND_OPTMU Compute per-user randomized scheduling probabilities.
%
% Inputs:
%   M  Number of users.
%   N  Maximum number of scheduled users per slot.
%
% Global configuration:
%   probabilityS, probabilityD  Per-user link success probabilities.
%   alpha                      Per-user AoI weights.
%
% Output:
%   optMU  Global M-by-1 vector, capped componentwise at one.
%
% The threshold increases by 1 percent until
% sum(optMU) <= N.

global probabilityS probabilityD alpha optMU

iterations = 200;

% Compute the end-to-end success probability for each source.
probability = probabilityS .* probabilityD; % Elementwise product of the two link reliabilities.

% Read the per-user AoI weights.
A = alpha;


% Initialize the global scheduling probability vector.
optMU = zeros(M, 1);

% Initialize the threshold and weight-to-reliability coefficients.
theta = sum(sqrt(probability  ./ A)) / (N^2);
vi = (A ./ (probability));
theta_i = max(vi);

% Cap each candidate scheduling probability at one.
mu = min(1, sqrt(vi / theta_i));
S = sum(mu);

% Increase the threshold until the scheduling budget is satisfied.
while S > N && theta_i > 0
    theta_i = theta_i * 1.01; % Increase the threshold by 1 percent.
    mu = min(1, sqrt(vi / theta_i));
    S = sum(mu);
end

% Return the final scheduling probabilities through the global variable.
optMU = mu;
end



