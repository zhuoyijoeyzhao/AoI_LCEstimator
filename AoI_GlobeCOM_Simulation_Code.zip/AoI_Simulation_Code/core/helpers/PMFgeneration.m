function [f] = PMFgeneration
% PMFGENERATION Construct conditional arrival probabilities for each source.
%
% Output:
%   f  M-by-1000 hazard table, where f(i,s) = P(X_i=s | X_i>=s).
%      X_i is the interarrival interval of source i.
%
% Global configuration:
%   Period      M-by-1 vector of per-source interval parameters.
%   prob_index  Arrival model: 1 = Bernoulli, 2 = periodic, 3 = uniform.
%   Uniform     M-by-2 matrix of discrete uniform interval bounds [L,U].
%
% The table supports the estimator; this function does not sample arrivals.

global Period prob_index Uniform

% Use a support length of 1000 interarrival slots.
num_bins = 1000;  % horizon for the hazard table
M = size(Period, 1);

f = zeros(M, num_bins);

% Geometric interarrival times have constant hazard 1/Period(i).
if prob_index == 1
    % Bernoulli arrival: memoryless constant hazard each slot
    % If Period is average inter-arrival time, then arrival prob per slot ~ 1/Period.
    T = Period(:, 1);
    for i = 1:M
        f(i, :) = 1 / T(i);
    end

% A deterministic interval has unit hazard at its prescribed period.
elseif prob_index == 2
    % Periodic arrivals: deterministic inter-arrival time = T
    % Hazard: 0 until T, then 1 at T, then (conceptually) reset.
    % Here we output a "single-cycle" hazard table for s=1..num_bins:
    T = Period(:, 1);
    for i = 1:M
        Ti = max(1, round(T(i)));
        f(i, :) = 0;
        if Ti <= num_bins
            f(i, Ti) = 1;
        else
            % if period larger than num_bins, hazard never triggers within table
            % keep zeros
        end
    end

% The discrete uniform hazard increases as 1/(U-s+1) on [L,U].
elseif prob_index == 3
    % Uniform inter-arrival time: X ~ Unif{L,...,U}
    % Hazard: lambda(s)=0 for s<L; 1/(U-s+1) for L<=s<=U; 1 for s>U
    startvalue = Uniform(:, 1);
    endvalue   = Uniform(:, 2);
    % 
    for i = 1:M
        L = round(startvalue(i));
        U = round(endvalue(i));

        % Guards
        L = max(1, min(L, num_bins));
        U = max(1, min(U, num_bins));
        if L > U
            tmp = L; L = U; U = tmp;
        end

        % Build hazard table
        h = zeros(1, num_bins);

        if L > 1
            h(1:L-1) = 0;
        end

        for s = L:U
            h(s) = 1 / (U - s + 1);
        end

        if U < num_bins
            h(U+1:end) = 1;  % outside support -> force arrival
        end

        f(i, :) = h;
    end

end

end
