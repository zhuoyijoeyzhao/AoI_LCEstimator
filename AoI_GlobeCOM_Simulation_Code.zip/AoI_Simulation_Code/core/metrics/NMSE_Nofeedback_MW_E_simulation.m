function [NMSE_avg, optimal_cost] = NMSE_Nofeedback_MW_E_simulation(K,T,M,h1,z1,Delay,num_iterations,set_Policy,N)
% NMSE_NOFEEDBACK_MW_E_SIMULATION Evaluate no-feedback estimation under dynamic uplinks.
%
% Inputs:
%   K              Simulation horizon in slots.
%   T              Time-scale factor applied to the final AoI cost.
%   M, N           Total users and scheduled users per slot, respectively.
%   h1, z1         Initial destination AoI and source-packet age.
%   Delay          Forwarding delay in slots.
%   num_iterations Number of independent repetitions.
%   set_Policy     Policy selector; 1 enables the Max-Weight branch.
%
% Outputs:
%   NMSE_avg       Mean squared relative error over evaluated user-slot samples:
%                  mean(((aligned_estimate-true_AoI)./true_AoI).^2).
%   optimal_cost   Weighted AoI sum, averaged over repetitions and scaled by T/K.
%                  This output is not divided by M.
%
% Global configuration:
%   probabilityS, probabilityD  Per-user uplink and destination-link reliabilities.
%   alpha                      Per-user AoI weights.
%   Period, Uniform            Interarrival parameters; Uniform has [lower, upper]
%                              bounds in each user row.
%   cost                       Per-user cost parameter.
%   prob_index                 Arrival type: 1 Bernoulli, 2 periodic, or
%                              3 uniform interarrival times.
%   arrival                    Mean arrival rates, read by this function or its
%                              arrival-probability helper.
%
% Notes:
%   Uplink reliability is sampled in coherence blocks using the state
%   probabilities, offsets, and bounds defined in this file.

global probabilityS probabilityD cost alpha Period prob_index Uniform 

%% Simulation Setup
% Load per-user link parameters with a trailing sentinel entry.
p = zeros(M,1);
p = [p + probabilityS; 0];

pD = zeros(M,1);
pD = [pD + probabilityD; 0];

A = zeros(M,1);
A = alpha;

C = zeros(M,1);
C = [C + cost; 0]; %#ok<NASGU>

Arr = zeros(M,1);
Arr = 1 ./ Period;

Per = Period;

% Build the arrival table used by the non-Bernoulli probability recursions.
f = PMFgeneration;

%% Dynamic uplink channel setup, NetSim-like coherence block
% Slot duration is assumed to be 1 ms. A 10 ms coherence block therefore
% corresponds to 10 consecutive scheduling slots.
% Configure block duration and channel-state parameters. Each user's uplink reliability is
% constant within a block.
COHERENCE_SLOTS = 10;

% Discrete channel-state model used to emulate SRS-based UL channel state.
% state = 1: bad, 2: nominal, 3: good.
% State-dependent offsets perturb the base uplink reliability;
% the resulting mean also depends on the state probabilities and clipping.
CHANNEL_STATE_PROB = [0.111 0.888 0.001];
CHANNEL_OFFSET     = [-0.99, 0.00, 0.30];

% If true, the scheduler knows the current SRS-based channel state perfectly.
% The gNB observes the current uplink success probability p_i^U(t).
PERFECT_SRS_OBSERVATION = true;

%% Simulation
real_q = zeros(M,num_iterations); %#ok<NASGU>
AoI    = zeros(M,num_iterations);

% ====== NMSE accumulator over all (iteration, slot, stream) ======
nmse_sum = 0;
nmse_cnt = 0;

% Reset the state for each independent repetition; average the accumulated results at the end.
for iteration = 1:1:num_iterations

    delivered = zeros(M+1,1);  
    c = zeros(M+1,1);  

    % Initialize the true destination AoI and source-packet age.
    h_history = h1 * ones(M,K);
    tauD_history = zeros(M,K); %#ok<NASGU>
    D_history = zeros(M,K);
    D_history(:,1) = ones(M,1);

    z = z1 * ones(M,K);

    % Store per-slot estimator output h_hat.
    h_hat_history = nan(M,K);

    vector_successful_tx = zeros(M,1);
    realvector_successful_tx = zeros(M,1); %#ok<NASGU>

    t_star = zeros(M,1);
    t_star_1 = zeros(M,1);    
    bar_t_star = zeros(M,1);
    bar_t_star_1 = zeros(M,1);    
    bar_t_star_2 = zeros(M,1); %#ok<NASGU>

    interarrivalfactor = ones(M,1);
    arrival_factor = zeros(M,1);

    % Store generation-time probability vectors by user and slot; vector entries follow reverse
    % chronological order.
    g_phi1_phi = cell(M,K);
    for i = 1:1:M
        g_phi1_phi{i,1} = 1;
    end

    servenode = zeros(N,K);

    lambda = Arr .* ones(M,K);
    lambda(:,1) = ones(M,1);

    for i = 1:1:M
        % Precompute renewal arrival probabilities to initialize the conditional estimator.
        lambda(i,2:K) = calculate_arrival_probabilities(i,K);
    end

    lambdaj = lambda;

    tauD_hat_lastslot = zeros(M,1);

    d = zeros(M,K);
    transmissiontime = zeros(M,K);
    tauD_hat_history = zeros(M,K); %#ok<NASGU>
    t_star_D = zeros(M,K); %#ok<NASGU>

    lastdeliveredpackets = zeros(M,1);

    %% Generate dynamic uplink reliability trace p_i^U(t)
    % pU_trace(i,t) is the UL success probability of UE i in slot t.
    % It is piecewise constant over each 10-slot coherence block.
    % Generate a blockwise uplink-reliability trace; individual transmission outcomes are
    % sampled separately.
    num_blocks = ceil(K / COHERENCE_SLOTS);
    pU_trace = zeros(M,K);

    for b = 1:num_blocks
        block_start = (b-1)*COHERENCE_SLOTS + 1;
        block_end   = min(b*COHERENCE_SLOTS, K);

        for node_index = 1:M
            ch_state = sample_ul_channel_state(CHANNEL_STATE_PROB);
            pU_block = channel_state_to_success_prob_centered( ...
                p(node_index), ch_state, CHANNEL_OFFSET);

            pU_trace(node_index, block_start:block_end) = pU_block;
        end
    end

    % Logs for actual UL/DL success of scheduled transmissions.
    % Row i corresponds to the i-th scheduled UE in that slot.
    ul_success_log = false(N,K);
    dl_success_log = false(N,K);

    % Update arrivals and estimates, schedule users, process deliveries, and update reception
    % observations.
    for slot_index = 1:1:K-1      

        %% Packet arrivals
        tauD_hat = zeros(M,1);
        tauA_hat = zeros(M,1);

        for node_index = 1:1:M
            % Sample Bernoulli arrivals each slot or wait for the next renewal arrival. A new
            % packet resets its source age and packet-state flags.
            if prob_index == 1
                if rand < Arr(node_index)
                    z(node_index,slot_index) = 0;
                    vector_successful_tx(node_index) = 0;
                    realvector_successful_tx(node_index) = 0;
                elseif slot_index > 1
                    z(node_index,slot_index) = z(node_index,slot_index-1) + 1;
                end
            else
                if arrival_factor(node_index) + interarrivalfactor(node_index) == slot_index
                    z(node_index,slot_index) = 0;
                    arrival_factor(node_index) = slot_index;

                    if prob_index == 2
                        interarrivalfactor(node_index) = Per(node_index);
                    elseif prob_index == 3
                        interarrivalfactor(node_index) = randi([Uniform(node_index,1), Uniform(node_index,2)]);
                    end

                    vector_successful_tx(node_index) = 0;
                    realvector_successful_tx(node_index) = 0;
                elseif slot_index > 1
                    z(node_index,slot_index) = z(node_index,slot_index-1) + 1;
                end
            end
        end

        %% MMSE Estimator
        for i = 1:1:M
            % Repeated receptions of the same packet exclude replacement arrivals between its
            % first and last receptions.
            lambda(i,t_star(i)+1:bar_t_star(i)) = 0;
            lambdaj(i,t_star(i)+1:bar_t_star(i)) = 0;
            lambda(i,t_star_1(i)+1:bar_t_star_1(i)) = 0;
            lambdaj(i,t_star_1(i)+1:bar_t_star_1(i)) = 0;

            % Restrict the generation window using distinct-packet reception boundaries and
            % normalize its probability mass.
            if t_star(i) > bar_t_star_1(i)
                lambdaj(i,bar_t_star_1(i)+1:t_star(i)) = ...
                    lambda(i,bar_t_star_1(i)+1:t_star(i)) / ...
                    (1 - prod(1 - lambda(i,bar_t_star_1(i)+1:t_star(i))));
            end

            lambdaj(i,bar_t_star(i)+1:slot_index) = lambda(i,bar_t_star(i)+1:slot_index);

            for tau = bar_t_star_1(i)+1:1:t_star(i)
                if tau > 1
                    g_phi1_phi{i,tau} = lambdaj(i,tau);
                    pfactor = 1 - lambdaj(i,tau);

                    for tauj = tau-1:-1:bar_t_star_1(i)+1
                        g_phi1_phi{i,tau}(end+1) = pfactor * lambdaj(i,tauj);
                        pfactor = pfactor * (1 - lambdaj(i,tauj));
                    end

                    g_phi1_phi{i,tau} = g_phi1_phi{i,tau} / sum(g_phi1_phi{i,tau});
                end
            end

            for tau = t_star(i)+1:1:slot_index
                if tau > 1
                    if prob_index ~= 1
                        if bar_t_star(i) > 1
                            lambda(i,tau) = 0;

                            for j = t_star_1(i):1:tau-1
                                g_phi1_phi{i,tau-1} = ...
                                    g_phi1_phi{i,tau-1} ./ sum(g_phi1_phi{i,tau-1});

                                if tau-j <= length(g_phi1_phi{i,tau-1})
                                    lambda(i,tau) = lambda(i,tau) + ...
                                        g_phi1_phi{i,tau-1}(tau-j) * f(i,tau-j); 
                                end
                            end
                        end
                    end

                    lambda(i,t_star(i)+1:bar_t_star(i)) = 0;
                    lambdaj(i,t_star(i)+1:bar_t_star(i)) = 0;
                    lambda(i,t_star_1(i)+1:bar_t_star_1(i)) = 0;
                    lambdaj(i,t_star_1(i)+1:bar_t_star_1(i)) = 0;

                    if t_star(i) > bar_t_star_1(i)
                        lambdaj(i,bar_t_star_1(i)+1:t_star(i)) = ...
                            lambda(i,bar_t_star_1(i)+1:t_star(i)) / ...
                            (1 - prod(1 - lambda(i,bar_t_star_1(i)+1:t_star(i))));
                    end

                    lambdaj(i,bar_t_star(i)+1:slot_index) = ...
                        lambda(i,bar_t_star(i)+1:slot_index);

                    g_phi1_phi{i,tau} = lambda(i,tau);
                    pfactor = 1 - lambda(i,tau);

                    for tauj = tau-1:-1:bar_t_star_1(i)+1
                        g_phi1_phi{i,tau}(end+1) = pfactor * lambdaj(i,tauj);
                        pfactor = pfactor * (1 - lambdaj(i,tauj));
                    end

                    g_phi1_phi{i,tau} = g_phi1_phi{i,tau} / sum(g_phi1_phi{i,tau});
                end
            end
        end

        %% Estimate tauA
        for i = 1:1:M
            for tau = slot_index:-1:bar_t_star_1(i)+1
                % Compute the source-packet timestamp as the probability-weighted mean of
                % candidate generation slots.
                tauA_hat(i) = tauA_hat(i) + ...
                    tau * g_phi1_phi{i,slot_index}(slot_index+1-tau);
            end
        end

        tauD_history(:,slot_index) = slot_index - h_history(:,slot_index);

        %% Estimate tauD[Di(t)]
        % Estimate the timestamp of the latest distinct packet received at the base station,
        % separately from destination delivery.
        tauD_hat_new = zeros(M,1);

        for i = 1:1:M
            for tau = t_star(i):-1:bar_t_star_1(i)+1
                tauD_hat_new(i) = tauD_hat_new(i) + ...
                    tau * g_phi1_phi{i,t_star(i)}(t_star(i)+1-tau);

                tauD_hat_history(i,d(i,slot_index)) = tauD_hat_new(i);
            end
        end

        %% Estimate tauD(t+theta_i)
        for i = 1:1:M
            if c(i) == 1
                % After a base-station reception, combine the previous destination estimate and
                % the received-packet estimate using pD.
                tauD_hat(i) = tauD_hat_lastslot(i) * (1 - pD(i)) + ...
                              tauD_hat_new(i) * pD(i);
                c(i) = 0;
            else
                tauD_hat(i) = tauD_hat_lastslot(i);
            end
        end

        tauD_hat_lastslot = tauD_hat;

        % Convert timestamp estimates to age estimates; delay alignment is applied separately
        % when evaluating errors.
        h_hat = slot_index - tauD_hat;
        z_hat = slot_index - tauA_hat;

        %% Record estimator output for this slot
        % Store the estimate for later alignment of the estimate at t-Delay with the true AoI at
        % t.
        h_hat_history(:,slot_index) = h_hat;

        %% Delayed-alignment NMSE accumulation
        % Compare estimate formed at (slot_index - Delay) to true AoI at slot_index.
        if slot_index - Delay >= 1
            h_true = h_history(:,slot_index);
            h_est  = h_hat_history(:,slot_index - Delay);

            valid = isfinite(h_est) & isfinite(h_true) & (h_true > 0);
            if any(valid)
                % Add Delay to align the estimate, normalize by the true AoI, and accumulate
                % squared relative error and sample count.
                err = (h_est(valid) + Delay - h_true(valid)) ./ h_true(valid);
                nmse_sum = nmse_sum + sum(err.^2);
                nmse_cnt = nmse_cnt + numel(err);
            end
        end

        %% Max-Weight policy with SRS-aware dynamic uplink reliability
        if set_Policy == 1
            if PERFECT_SRS_OBSERVATION
                pU_hat = pU_trace(:,slot_index);
            else
                % Use the current channel reliability for this observation mode.
                % The scheduling probability equals the channel reliability.
                pU_hat = pU_trace(:,slot_index);
            end

            % Max-Weight scheduling score:
            % W_i(t) = beta_i p_i^U(t) p_i^D (Ahat_i - ahat_i - theta_i).
            % Here A is used as the weight/design parameter.
            % Compute the dynamic-channel weight A .* pU_hat .* pD .* (h_hat-z_hat).
            % Sort the current weights in descending order and select the first N users.
            weight = A(1:M) .* pU_hat(1:M) .* pD(1:M) .* (h_hat - z_hat);

            [~, sorted_indices] = sort(weight, 'descend');
            servenode(:,slot_index) = sorted_indices(1:N);
        end    

        %% AoI accumulation and default AoI evolution
        % Accumulate weighted true AoI, then apply the default one-slot increment before
        % delivery-specific updates.
        AoI(:,iteration) = AoI(:,iteration) + A(1:M) .* h_history(:,slot_index);       
        h_history(:,slot_index+1) = h_history(:,slot_index) + 1;
        d(:,slot_index+1) = d(:,slot_index);

        %% Transmission, observation, and delayed destination update
        for i = 1:1:N

            %% Receive process at the destination
            % A packet scheduled in slot tx_slot reaches the destination
            % after Delay slots if both UL and destination-link transmissions
            % were successful.
            if slot_index > Delay
                % Read the scheduled user and link outcomes from Delay slots earlier; reset AoI
                % only for a fresher delivered packet.
                tx_slot = slot_index - Delay;
                node_index = servenode(i,tx_slot);

                if node_index ~= (M+1)
                    if ul_success_log(i,tx_slot) && dl_success_log(i,tx_slot) && ...
                            (d(node_index,tx_slot+1) > lastdeliveredpackets(node_index))

                        delivered(node_index) = delivered(node_index) + 1;
                        h_history(node_index,slot_index+1) = z(node_index,tx_slot) + Delay + 1;
                        D_history(node_index,slot_index+1) = 1;
                        lastdeliveredpackets(node_index) = d(node_index,tx_slot+1);
                    end
                end
            end

            %% Observation process at the gNB
            % Update base-station observations from uplink reception, distinguishing a new
            % packet from a repeated copy.
            node_index = servenode(i,slot_index);

            if node_index ~= (M+1)

                % Current-slot dynamic UL reliability from the 10-slot
                % coherence-block channel model.
                pU_current = pU_trace(node_index,slot_index);

                % Separate UL and destination-link success events.
                % Sample uplink success, then destination-link success conditional on reception;
                % log both outcomes for delayed delivery.
                ul_success = (rand < pU_current);
                dl_success = false;

                if ul_success
                    dl_success = (rand < pD(node_index));
                end

                ul_success_log(i,slot_index) = ul_success;
                dl_success_log(i,slot_index) = dl_success;

                % gNB observes successful UL reception immediately.
                if ul_success && (vector_successful_tx(node_index) == 0)
                    % First successful reception of a newly generated packet.
                    vector_successful_tx(node_index) = 1;
                    % For a newly observed packet, increment its index, initialize its reception
                    % count, and shift the reception boundaries.
                    d(node_index,slot_index+1) = d(node_index,slot_index) + 1;
                    transmissiontime(node_index,d(node_index,slot_index+1)) = 1;

                    c(node_index) = 1;

                    t_star_1(node_index) = t_star(node_index);
                    t_star(node_index) = slot_index;
                    t_star_D(node_index,d(node_index,slot_index+1)) = slot_index;

                    bar_t_star_2(node_index) = bar_t_star_1(node_index);
                    bar_t_star_1(node_index) = bar_t_star(node_index);
                    bar_t_star(node_index) = t_star(node_index);

                elseif ul_success && (vector_successful_tx(node_index) == 1)
                    % Repeated successful reception of the same currently
                    % stored packet.
                    % For a repeated packet, update its last reception and count while
                    % preserving its first reception time.
                    bar_t_star(node_index) = slot_index;

                    transmissiontime(node_index,d(node_index,slot_index+1)) = ...
                        transmissiontime(node_index,d(node_index,slot_index+1)) + 1;

                    c(node_index) = 1;
                end
            end
        end
    end

    real_q(:,iteration) = delivered(1:M) / K; %#ok<NASGU>
end

% Average across repetitions, scale by T/K, and sum over users. Per-user averaging is left to
% the caller.
AoI_average_GRE = mean(AoI,2); 
optimal_cost_clients = T * AoI_average_GRE(:) / K;
optimal_cost = sum(optimal_cost_clients);

if nmse_cnt > 0
    NMSE_avg = nmse_sum / nmse_cnt;
else
    NMSE_avg = NaN;
end

end


% Sample a channel-state index from the cumulative state probabilities.
function state = sample_ul_channel_state(state_prob)
%SAMPLE_UL_CHANNEL_STATE Draw a discrete UL channel state.
% state = 1: bad, 2: nominal, 3: good.

    r = rand;
    cdf = cumsum(state_prob(:));

    state = find(r <= cdf, 1, 'first');

    if isempty(state)
        state = numel(state_prob);
    end
end


% Add the selected state offset to the base reliability and apply the probability bounds below.
function pU = channel_state_to_success_prob_centered(base_p, state, offset)
%CHANNEL_STATE_TO_SUCCESS_PROB_CENTERED
% Map a discrete SRS/channel state to an uplink success probability.
%
% base_p is the baseline uplink success probability probabilityS(i).
% offset(state) perturbs base_p according to the current channel condition.
% The result is clipped to [0.01, 0.99].

    pU = base_p + offset(state);
    pU = min(max(pU, 0.01), 0.99);
end

