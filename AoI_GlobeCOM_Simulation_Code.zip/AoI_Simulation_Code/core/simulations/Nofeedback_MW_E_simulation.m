function [actual_throughput,optimal_cost] = Nofeedback_MW_E_simulation(K,T,M,h1,z1,Delay,num_iterations,set_Policy,N)
% NOFEEDBACK_MW_E_SIMULATION Simulate no-feedback Max-Weight with static links.
%
% Inputs:
%   K              Simulation horizon in slots.
%   T              Time-scale factor applied to the final AoI cost.
%   M, N           Total users and scheduled users per slot, respectively.
%   h1, z1         Initial destination AoI and source-packet age.
%   Delay          Forwarding delay in slots.
%   num_iterations Number of independent repetitions.
%   set_Policy     Policy selector; 1 enables the Max-Weight branch.
%
% Outputs:
%   actual_throughput  M-by-1 mean delivery-count rate, delivered/K.
%   optimal_cost   Weighted AoI sum, averaged over repetitions and scaled by T/K.
%                  This output is not divided by M.
%
% Global configuration:
%   probabilityS, probabilityD  Per-user uplink and destination-link reliabilities.
%   alpha                      Per-user AoI weights.
%   Period, Uniform            Interarrival parameters; Uniform has [lower, upper]
%                              bounds in each user row.
%   cost                       Per-user cost parameter.
%   prob_index                 Arrival type: 1 Bernoulli, 2 periodic, or
%                              3 uniform interarrival times.
%   arrival                    Mean arrival rates, read by this function or its
%                              arrival-probability helper.

global probabilityS probabilityD cost alpha Period prob_index Uniform 

%% Simulation Setup
% Load per-user link parameters with a trailing sentinel entry.
p=zeros(M,1);
p=[p+probabilityS;0];

pD=zeros(M,1);
pD=[pD+probabilityD;0]; %Making sure that "probability" has the right size

A =zeros(M,1);
A =alpha; %Making sure that "alpha" has the right size

C =zeros(M,1);
C =[C+cost;0]; %Making sure that "cost" has the right size

Arr =zeros(M,1);
Arr = 1./Period;  %Making sure that "arrival" has the right size

Per = Period;

% Build the arrival table used by the non-Bernoulli probability recursions.
f = PMFgeneration;

%% Simulation
real_q=zeros(M,num_iterations);
AoI=zeros(M,num_iterations);

% Reset the state for each independent repetition; average the accumulated results at the end.
for iteration=1:1:num_iterations

    delivered=zeros(M+1,1);  
    c=zeros(M+1,1);  
    % Initialize the true destination AoI and source-packet age.
    h_history=h1*ones(M,K);
    tauD_history = zeros(M,K);
    D_history = zeros(M,K);
    D_history(:,1)=ones(M,1);
    z=z1*ones(M,K);
    vector_successful_tx=zeros(M,1);
    t_star = zeros(M, 1);
    t_star_1 = zeros(M, 1);    
    bar_t_star = zeros(M, 1);
    bar_t_star_1 = zeros(M, 1);    
    interarrivalfactor = ones(M,1);
    % Store generation-time probability vectors by user and slot; vector entries follow reverse
    % chronological order.
    g_phi1_phi = cell(M,K);
    servenode = zeros(N,K);
    for i = 1:1:M
        g_phi1_phi{i,1} =  1;
    end
    lambda=Arr.*ones(M,K);
    lambda(:,1) = ones(M,1);
    for i = 1:1:M
        % Precompute renewal arrival probabilities to initialize the conditional estimator.
        lambda(i,2:K)=calculate_arrival_probabilities(i,K);
    end
    lambdaj=lambda;
    arrival_factor = zeros(M,1);
    tauD_hat_lastslot  = zeros(M,1);
    realvector_successful_tx = zeros(M,1);
    d = zeros(M,K);
    transmissiontime = zeros(M,K);
    tauD_hat_history=zeros(M,K);
    t_star_D =zeros(M,K); 
    success_factor = zeros(N,K);
    lastdeliveredpackets = zeros(M,1);
    % Update arrivals and estimates, schedule users, process deliveries, and update reception
    % observations.
    for slot_index=1:1:K-1      
        % Estimation of real time h
        tauD_hat = zeros(M,1);
        tauA_hat = zeros(M,1);
        for node_index=1:1:M
            % Packets Arrival
                % Sample Bernoulli arrivals each slot or wait for the next renewal arrival. A
                % new packet resets its source age and packet-state flags.
                if prob_index == 1
                    if rand<Arr(node_index)
                        z(node_index,slot_index)=0;
                        vector_successful_tx(node_index)=0;% new arrival
                        realvector_successful_tx(node_index)=0;
                    elseif slot_index>1
                        z(node_index,slot_index)=z(node_index,slot_index-1)+1;
                    end
                else
                    if arrival_factor(node_index) + interarrivalfactor(node_index) == slot_index
                        z(node_index,slot_index)=0;
                        arrival_factor(node_index) = slot_index;
                        if prob_index == 2
                            interarrivalfactor(node_index) = Per(node_index);
                        elseif prob_index == 3
                            interarrivalfactor(node_index) = randi([Uniform(node_index,1), Uniform(node_index,2)]);
                        end
                        vector_successful_tx(node_index)=0;% new arrival
                        realvector_successful_tx(node_index)=0;
                    elseif slot_index>1
                        z(node_index,slot_index)=z(node_index,slot_index-1)+1;
                    end
                end

        end
%% MMSE Estimator
        for i =1:1:M
            % Repeated receptions of the same packet exclude replacement arrivals between its
            % first and last receptions.
            lambda(i,t_star(i)+1:bar_t_star(i))=0;
            lambdaj(i,t_star(i)+1:bar_t_star(i))=0;
            lambda(i,t_star_1(i)+1:bar_t_star_1(i))=0;
            lambdaj(i,t_star_1(i)+1:bar_t_star_1(i))=0;

            % Restrict the generation window using distinct-packet reception boundaries and
            % normalize its probability mass.
            if t_star(i)>bar_t_star_1(i)
               lambdaj(i,bar_t_star_1(i)+1:t_star(i))=lambda(i,bar_t_star_1(i)+1:t_star(i))/ ...
                            (1-prod(1-lambda(i,bar_t_star_1(i)+1:t_star(i))));
            end
            lambdaj(i,bar_t_star(i)+1:slot_index)=lambda(i,bar_t_star(i)+1:slot_index);
            for tau = bar_t_star_1(i)+1:1:t_star(i)
                if tau>1 
                    g_phi1_phi{i, tau} = lambdaj(i, tau);
                    pfactor=1-lambdaj(i, tau);
                    if tau > 1 
                        for tauj = tau-1:-1:bar_t_star_1(i)+1 
                            g_phi1_phi{i, tau}(end+1) = pfactor*lambdaj(i, tauj);
                            pfactor = pfactor*(1-lambdaj(i, tauj));
                        end
                    end
                    g_phi1_phi{i, tau} = g_phi1_phi{i, tau}/sum(g_phi1_phi{i, tau});
                end
            end

            for tau = t_star(i)+1:1:slot_index
                if tau>1
                    if prob_index ~= 1
                        if bar_t_star(i)>1
                            lambda(i,tau) = 0;
                            for j = t_star_1(i):1:tau-1
                                g_phi1_phi{i,tau-1}=g_phi1_phi{i,tau-1}./sum(g_phi1_phi{i,tau-1});
                                if tau-j<=length(g_phi1_phi{i,tau-1})
                                    lambda(i,tau) = lambda(i,tau) + g_phi1_phi{i,tau-1}(tau-j)*f(i,tau-j); 
                                end
                            end
                        end
                    end

                    lambda(i,t_star(i)+1:bar_t_star(i))=0;
                    lambdaj(i,t_star(i)+1:bar_t_star(i))=0;
                    lambda(i,t_star_1(i)+1:bar_t_star_1(i))=0;
                    lambdaj(i,t_star_1(i)+1:bar_t_star_1(i))=0;

                    if t_star(i)>bar_t_star_1(i)
                        lambdaj(i,bar_t_star_1(i)+1:t_star(i))=lambda(i,bar_t_star_1(i)+1:t_star(i))/ ...
                            (1-prod(1-lambda(i,bar_t_star_1(i)+1:t_star(i))));
                    end
                    lambdaj(i,bar_t_star(i)+1:slot_index)=lambda(i,bar_t_star(i)+1:slot_index);
                    g_phi1_phi{i, tau} = lambda(i, tau);
                    pfactor=1-lambda(i, tau);
                    if tau > 1
                        for tauj = tau-1:-1:bar_t_star_1(i)+1 
                            g_phi1_phi{i, tau}(end+1) = pfactor*lambdaj(i, tauj);
                            pfactor = pfactor*(1-lambdaj(i, tauj));
                        end
                    end
                    g_phi1_phi{i, tau} = g_phi1_phi{i, tau}/sum(g_phi1_phi{i, tau});
                end
            end
        end
        % Estimate tauA
        for i=1:1:M
            for tau = slot_index:-1:bar_t_star_1(i)+1
                % Compute the source-packet timestamp as the probability-weighted mean of
                % candidate generation slots.
                tauA_hat(i) = tauA_hat(i) + tau*g_phi1_phi{i, slot_index}(slot_index+1-tau);
            end
        end
        tauD_history(:,slot_index) = slot_index-h_history(:,slot_index);
        % Estimate the timestamp of the latest distinct packet received at the base station,
        % separately from destination delivery.
        tauD_hat_new = zeros(M,1);
        
        % Estimate tauD[Di(t)]
        for i=1:1:M
                for tau = t_star(i):-1:bar_t_star_1(i)+1
                    tauD_hat_new(i) = tauD_hat_new(i) + tau*g_phi1_phi{i, t_star(i)}(t_star(i)+1-tau);
                    tauD_hat_history(i,d(i,slot_index)) = tauD_hat_new(i);
                end
        end
        % Estimate tauD(t+theta_i)
        for i=1:1:M
                if c(i)==1
                    % After a base-station reception, combine the previous destination estimate
                    % and the received-packet estimate using pD.
                    tauD_hat(i)  = tauD_hat_lastslot(i) *(1-pD(i))+tauD_hat_new(i) *pD(i);
                    c(i)=0;
                else
                    tauD_hat(i)  = tauD_hat_lastslot(i);
                end
        end

        tauD_hat_lastslot = tauD_hat;
        % Convert timestamp estimates to age estimates; delay alignment is applied separately
        % when evaluating errors.
        h_hat = slot_index - tauD_hat;
        z_hat = slot_index - tauA_hat;
%% Max_Weight policy
        if set_Policy==1 % Max Weight                
            % Rank sqrt(alpha*pS*pD) times the age reduction and select the first N users.
            [~, sorted_indices] = sort(sqrt(A(1:M).*p(1:M).*pD(1:M)).*(h_hat-z_hat),'descend');
            servenode(:,slot_index) = sorted_indices(1:N);
        end    
        % Accumulate weighted true AoI, then apply the default one-slot increment before
        % delivery-specific updates.
        AoI(:,iteration)=AoI(:,iteration)+A(1:M).*h_history(:,slot_index);       
        h_history(:,slot_index+1)=h_history(:,slot_index)+1;
        d(:,slot_index+1)=d(:,slot_index);
        
        for i=1:1:N
            % receive process at the destination
                success_factor(i,slot_index) = rand;
                if slot_index > Delay
                    % Process the transmission scheduled Delay slots earlier and update AoI from
                    % that packet's source age when delivery conditions hold.
                    node_index = servenode(i,slot_index-Delay);
                    if (node_index~=(M+1)) && (success_factor(i,slot_index-Delay)<p(node_index)*pD(node_index)) && (d(node_index,slot_index-Delay+1)>lastdeliveredpackets(node_index))
                        delivered(node_index)=delivered(node_index)+1;     
                        h_history(node_index,slot_index+1)=z(node_index,slot_index-Delay)+Delay+1;
                        D_history(node_index,slot_index+1)=1;
                        lastdeliveredpackets(node_index)=d(node_index,slot_index-Delay+1);
                    end
                end
%% observation process at the BS
                % Update base-station observations from uplink reception, distinguishing a new
                % packet from a repeated copy.
                node_index = servenode(i,slot_index);

                if (node_index~=(M+1)) && (success_factor(i,slot_index)<p(node_index)) && (vector_successful_tx(node_index)==0)
                    vector_successful_tx(node_index)=1;
                    % For a newly observed packet, increment its index, initialize its reception
                    % count, and shift the reception boundaries.
                    d(node_index,slot_index+1)=d(node_index,slot_index)+1;
                    transmissiontime(node_index,d(node_index,slot_index+1))=1;
                    c(node_index)= 1;
                    t_star_1(node_index) = t_star(node_index); 
                    t_star(node_index) = slot_index;
                    t_star_D(node_index,d(node_index,slot_index+1))=slot_index;
                    bar_t_star_1(node_index) = bar_t_star(node_index);
                    bar_t_star(node_index)=t_star(node_index);
    
                elseif (node_index~=(M+1)) && (success_factor(slot_index)<p(node_index))&& (vector_successful_tx(node_index)==1)
                    % For a repeated packet, update its last reception and count while
                    % preserving its first reception time.
                    bar_t_star(node_index) = slot_index;
                    transmissiontime(node_index,d(node_index,slot_index+1))=transmissiontime(node_index,d(node_index,slot_index+1))+1;
                    c(node_index)= 1;
                end

        end
    end
    real_q(:,iteration)=delivered(1:M)/K;

end
% Average across repetitions, scale by T/K, and sum over users. Per-user averaging is left to
% the caller.
AoI_average_GRE=mean(AoI,2); 
optimal_cost_clients=T*AoI_average_GRE(:)/K;
optimal_cost=sum(optimal_cost_clients);
actual_throughput=mean(real_q,2);
end
