function [actual_throughput,optimal_cost] = MW_E_simulation(K,T,M,h1,z1,Delay,num_iterations,set_Policy,N)
% MW_E_SIMULATION Simulate Max-Weight scheduling with delayed AoI feedback.
%
% Inputs:
%   K              Simulation horizon in slots.
%   T              Time-scale factor applied to the final AoI cost.
%   M, N           Total users and scheduled users per slot, respectively.
%   h1, z1         Initial destination AoI and source-packet age.
%   Delay          Forwarding delay in slots.
%   num_iterations Number of independent repetitions.
%   set_Policy     Policy selector; 1 enables the Max-Weight branch.
%
% Outputs:
%   actual_throughput  M-by-1 mean delivery-count rate, delivered/K.
%   optimal_cost   Weighted AoI sum, averaged over repetitions and scaled by T/K.
%                  This output is not divided by M.
%
% Global configuration:
%   probabilityS, probabilityD  Per-user uplink and destination-link reliabilities.
%   alpha                      Per-user AoI weights.
%   Period, Uniform            Interarrival parameters; Uniform has [lower, upper]
%                              bounds in each user row.
%   cost                       Per-user cost parameter.
%   prob_index                 Arrival type: 1 Bernoulli, 2 periodic, or
%                              3 uniform interarrival times.
%   arrival                    Mean arrival rates, read by this function or its
%                              arrival-probability helper.

global probabilityS probabilityD cost alpha Period prob_index Uniform 

%% Simulation Setup
% Load per-user link parameters with a trailing sentinel entry.
p=zeros(M,1);
p=[p+probabilityS;0];

pD=zeros(M,1);
pD=[pD+probabilityD;0]; % Ensure the probability vector has the right size

A =zeros(M,1);
A =alpha; % Ensure alpha has the right size

C =zeros(M,1);
C =[C+cost;0]; % Ensure cost has the right size

Arr =zeros(M,1);
Arr = 1./Period;  % Ensure arrival has the right size

Per = Period;

% Build the arrival table used by the non-Bernoulli probability recursions.
f = PMFgeneration;

%% Simulation
real_q=zeros(M,num_iterations);
AoI=zeros(M,num_iterations);

% Reset the state for each independent repetition; average the accumulated results at the end.
for iteration=1:1:num_iterations

    delivered=zeros(M+1,1);  
    c=zeros(M+1,1);  
    % Initialize the true destination AoI and source-packet age.
    h_history=h1*ones(M,K);
    tauD_history = ones(M,K);
    D_history = zeros(M,K);
    D_history(:,1)=ones(M,1);
    z=z1*ones(M,K);

    vector_successful_tx=zeros(M,1);

    % Store per-user, per-packet reception boundaries in M-by-K arrays.
    t_star     = zeros(M, K);   % second dimension is the packet index (d counter)
    bar_t_star = zeros(M, K);   % second dimension is the packet index

    % Store reception boundaries for each delivered packet.
    t_star_D   = zeros(M, K); 

    interarrivalfactor = ones(M,1);
    % Store generation-time probability vectors by user and slot; vector entries follow reverse
    % chronological order.
    g_phi1_phi = cell(M,K);

    servenode = zeros(N,K);

    for i = 1:1:M
        g_phi1_phi{i,1} =  1;
    end

    lambda=Arr.*ones(M,K);
    lambda(:,1) = ones(M,1);
    for i = 1:1:M
        % Precompute renewal arrival probabilities to initialize the conditional estimator.
        lambda(i,2:K)=calculate_arrival_probabilities(i,K);
    end
    lambdaj=lambda;
    rebuild_from_pkt = zeros(M,1); % packet index to start re-estimation (per source)
    arrival_factor = zeros(M,1);
    tauD_hat_lastslot  = zeros(M,1);
    realvector_successful_tx = zeros(M,1);
    d = zeros(M,K);
    transmissiontime = zeros(M,K);
    tauD_hat_history=zeros(M,K);
    % Store delivery-belief weights by user and distinct-packet index.
    belief = zeros(M, K);  % belief per source (row) and packet index (column)
    success_factor = zeros(N,K);
    lastdeliveredpackets = zeros(M,1);

    % Track the latest delayed AoI feedback for each source.
    fb_last_age=zeros(M,1);
    if isempty(fb_last_age) || numel(fb_last_age)~=M
        fb_last_age = ones(M,1);
    end
    
    % Update arrivals and estimates, schedule users, process deliveries, and update reception
    % observations.
    for slot_index=1:1:K-1      

        tauD_hat = zeros(M,1);
        tauA_hat = zeros(M,1);

        % ---------------- Packets Arrival ----------------
        for node_index=1:1:M
            % Sample Bernoulli arrivals each slot or wait for the next renewal arrival. A new
            % packet resets its source age and packet-state flags.
            if prob_index == 1
                if rand<Arr(node_index)
                    z(node_index,slot_index)=0;
                    vector_successful_tx(node_index)=0;   % new arrival
                    realvector_successful_tx(node_index)=0;
                elseif slot_index>1
                    z(node_index,slot_index)=z(node_index,slot_index-1)+1;
                end
            else
                if arrival_factor(node_index) + interarrivalfactor(node_index) == slot_index
                    z(node_index,slot_index)=0;
                    arrival_factor(node_index) = slot_index;
                    if prob_index == 2
                        interarrivalfactor(node_index) = Per(node_index);
                    elseif prob_index == 3
                        interarrivalfactor(node_index) = randi([Uniform(node_index,1), Uniform(node_index,2)]);
                    end
                    vector_successful_tx(node_index)=0;   % new arrival
                    realvector_successful_tx(node_index)=0;
                elseif slot_index>1
                    z(node_index,slot_index)=z(node_index,slot_index-1)+1;
                end
            end
        end



        % ===================== FEEDBACK-DRIVEN RECONSTRUCTION =====================
        % Assumption: transmission delay == feedback delay == Delay.
        % Idea: if the delayed AoI feedback at this slot differs from the last one
        % (here we check "~= fb_last_age + 1" to be robust), we treat it as a
        % new confirmed delivery. Then:
        %   1) Infer generation time t0 = slot_index - Delay - curr_fb_age.
        %   2) Force lambda(i, t0)=1; and set lambda=0, lambdaj=0 for (t0+1 : bar_t_star(i, pkt_idx))
        %   3) Rebuild (lambda -> lambdaj -> g_phi1_phi) from t0 up to slot_index

        pmf_rebuilt = false(M,1);

        if slot_index > Delay
            for i = 1:M
                % A delayed AoI value that differs from the previous value plus one indicates a
                % destination update.
                % Recover the generation timestamp from the feedback time and AoI, then rebuild
                % the affected probability history.
                curr_fb_age = h_history(i, slot_index-Delay);    % delayed AoI feedback at current slot
                if curr_fb_age ~= fb_last_age(i)+1
                    % ---- 1) Feedback indicates a confirmed generation time t0 ----
                    t0 = slot_index-Delay - curr_fb_age;                % inferred generation time
                    pmf_rebuilt(i) = true;
                     % remember where re-estimation should start
                    % Packet index associated with this delivery:
                    % Locate the packet index in the delayed reception record.
                    pkt_idx = d(i, max(slot_index-2*Delay-1,1));    % guard with 1 if zero
                    % Record the packet confirmed by feedback to identify the history that must
                    % be recomputed.
                    rebuild_from_pkt(i) = pkt_idx;
                    % Segment right end (last transmission time of this packet)
                    bs_cur = bar_t_star(i, pkt_idx);
                    if pkt_idx>1
                        bs_prv = bar_t_star(i, pkt_idx-1);
                    else
                        bs_prv =0;
                    end
        
                    % ---- 2) Force lambda constraints on the packet interval ----
                    % t0 must have an arrival; then no new arrival from (t0+1 .. bs_cur)
                    lambda(i, t0) = 1;
                    lambdaj(i, t0) = 1;
                    if t0+1 <= bs_cur
                        lambda(i, t0+1:bs_cur)  = 0;
                        lambdaj(i, t0+1:bs_cur) = 0;
                    end
                    g_phi1_phi{i, t0} = 1;
                    % ---- 3) Rebuild lambda / lambdaj / g starting from t0 ----
                    % Apply the forward hazard recurrence from the confirmed generation time.

        
                    % ---------- Build a "blocked" mask for gen-forbidden slots ----------
                    % All known transmission intervals [t_star+1 .. bar_t_star] are "no-generation" slots.
                    blocked_mask = false(1, slot_index);
                    for k_blk = 1:K
                        ts_blk = t_star(i, k_blk);
                        bs_blk = bar_t_star(i, k_blk);
                        if ts_blk > 0 && bs_blk > 0
                            L = max(ts_blk+1, 1);
                            R = min(bs_blk,     slot_index);
                            if L <= R
                                blocked_mask(L:R) = true;
                            end
                        end
                    end
                    % Also block (t0+1 .. bs_cur) for the current packet interval
                    if t0+1 <= bs_cur
                        blocked_mask(t0+1:bs_cur) = true;
                    end
                    
                    % ---------- Rebuild lambda, lambdaj, and g from (t0+1) to slot_index ----------
                    for tau = max(t0+1, 2) : slot_index
                    
                        % If tau is in a blocked interval: explicitly set to zero (keep index aligned)
                        if blocked_mask(tau)
                            lambda(i,  tau) = 0;
                            lambdaj(i, tau) = 0;
                        else
                            % Forward update for lambda(i,tau): traverse all j, but zero
                            % out contributions from blocked j (index alignment preserved).
                                lambda(i, tau) = 0;
                                    jL =  t0;
                                    jR = tau - 1;
                                    if jL <= jR
                                        for j = jL : jR
                                            idx_g = tau - j;
                                            if idx_g >= 1 && idx_g <= length(g_phi1_phi{i, tau-1})
                                                mask_j = double(~blocked_mask(j));
                                                lambda(i, tau) = lambda(i, tau) + ...
                                                    mask_j * g_phi1_phi{i, tau-1}(idx_g) * f(i, idx_g);
                                            end
                                        end
                                    end
                        end
                        lambdaj(i, tau) = lambda(i, tau);
                        if t_star(i,max(d(i, tau),1))>bar_t_star(i,max(d(i, tau)-1,1))
                            lambdaj(i,bar_t_star(i,max(d(i, tau)-1,1))+1:t_star(i,max(d(i, tau),1)))=lambda(i,bar_t_star(i,max(d(i, tau)-1,1))+1:t_star(i,max(d(i, tau),1)))/(1-prod(1-lambda(i,bar_t_star(i,max(d(i, tau)-1,1))+1:t_star(i,max(d(i, tau),1)))));
                        end
                        % Build g_phi1_phi{i,tau} without skipping any indices
                        g_phi1_phi{i, tau} = lambdaj(i, tau);  % if tau is blocked, this is 0
                        
                        % Other components: "generated at tauj and no generation until tau"
                        pfactor = 1 - lambdaj(i, tau);
                        if tau > 1
                            if d(i,tau)<=1
                                for tauj = tau-1 : -1 : 1
                                    % Generation term is 0 if tauj is blocked; survival term continues.
                                    gen_term = (pfactor * lambdaj(i, tauj)) * double(~blocked_mask(tauj));
                                    g_phi1_phi{i, tau}(end+1) = gen_term;
                                    pfactor = pfactor * (1 - lambdaj(i, tauj));
                                end
                            else
                                for tauj = tau-1 : -1 : bar_t_star(i, d(i,tau)-1)+1
                                    % Generation term is 0 if tauj is blocked; survival term continues.
                                    gen_term = (pfactor * lambdaj(i, tauj)) * double(~blocked_mask(tauj));
                                    g_phi1_phi{i, tau}(end+1) = gen_term;
                                    pfactor = pfactor * (1 - lambdaj(i, tauj));
                                end
                            end
                        end
                    
                        % Normalize (fallback to unit mass if everything is zero)
                        ssum = sum(g_phi1_phi{i, tau});
                        if ssum == 0
                            keyboard;
                        end
                        g_phi1_phi{i, tau} = g_phi1_phi{i, tau} / ssum;
                    end
        
                    % Record current feedback age for the next-slot comparison
                end
                fb_last_age(i) = curr_fb_age;
            end
        end
        % =================== END FEEDBACK-DRIVEN RECONSTRUCTION ====================
        % --------- Timestamp updates from received feedback ---------
        % Use received or absent feedback to revise timestamp history and delivery beliefs for
        % unresolved packets.
        if slot_index > 2*Delay
            for i = 1:M
                % Recompute packet timestamps from the first affected packet after a
                % probability-history update.
                if pmf_rebuilt(i)
                    % packet index that was just confirmed by feedback this slot
                    % Use the feedback-confirmed packet index to correct the associated
                    % timestamp history.
                    k_del = rebuild_from_pkt(i);
                    if k_del > 0
                        % true generation time from delayed AoI feedback
                        t0 = slot_index-Delay - h_history(i, slot_index - Delay);
                        t0 = max(1, min(t0, K));  % clamp to [1, K]
                        % overwrite the MMSE estimate with the ground truth
                        tauD_hat_history(i, 1:k_del) = t0;
                    end
                end
            end
        end
        % ---------------- Generate PMF ----------------
        for i =1:1:M
            
            % Derive reception-boundary indices from the current packet identifier.
            d_now   = max(d(i, slot_index),1);
            idx_now = d_now;
            idx_prv = d_now-1;
            ts     = t_star(i, idx_now);       % current segment start
            bs     = bar_t_star(i, idx_now);   % current segment right end
            if idx_prv == 0
                bs_prv = 0; 
                ts_prv = 0;       % previous segment start
            else
                bs_prv = bar_t_star(i, idx_prv); 
                ts_prv = t_star(i, idx_prv);       % previous segment start
            end
            if idx_prv >1
                bs_prv_1 = bar_t_star(i, idx_prv-1); 
            else
                bs_prv_1 = 0; 
            end
            if ts+1<=bs
                lambda(i, ts+1:bs)=0;
                lambdaj(i, ts+1:bs)=0;
            end
            if ts_prv+1<=bs_prv
                lambda(i, ts_prv+1:bs_prv)=0;
                lambdaj(i, ts_prv+1:bs_prv)=0;
            end
            if ts>bs_prv
                        denom = 1 - prod(1 - lambda(i, bs_prv+1:ts));
                        lambdaj(i, bs_prv+1:ts) = lambda(i, bs_prv+1:ts)/denom;
            end
            % ---- build g on (ts_prv+1 : ts) ----
            for tau = ts_prv+1:1:ts
                if tau>1
                    g_phi1_phi{i, tau} = lambdaj(i, tau);
                    pfactor=1-lambdaj(i, tau);
                    if tau<ts
                        for tauj = tau-1:-1:bs_prv_1+1 
                            g_phi1_phi{i, tau}(end+1) = pfactor*lambdaj(i, tauj);
                            pfactor = pfactor*(1-lambdaj(i, tauj));
                        end
                    else
                        for tauj = tau-1:-1:bs_prv+1 
                            g_phi1_phi{i, tau}(end+1) = pfactor*lambdaj(i, tauj);
                            pfactor = pfactor*(1-lambdaj(i, tauj));
                        end
                        g_phi1_phi{i, tau} = g_phi1_phi{i, tau}/sum(g_phi1_phi{i, tau});
                    end
                end
            end

            % ---- propagate forward: (ts+1 : slot_index) ----
            for tau = ts+1:1:slot_index
                if tau>1
                    if prob_index ~= 1
                        if bs>1
                            lambda(i,tau) = 0;
                            for j = ts_prv:1:tau-1
                                if tau-j<=length(g_phi1_phi{i,tau-1})
                                    lambda(i,tau) = lambda(i,tau) + g_phi1_phi{i,tau-1}(tau-j)*f(i,tau-j); 
                                end
                            end
                        end
                    end
                    g_phi1_phi{i, tau} = lambdaj(i, tau);
                    pfactor=1-lambdaj(i, tau);
                    if tau > 1
                        for tauj = tau-1:-1:bs_prv+1 
                            g_phi1_phi{i, tau}(end+1) = pfactor*lambdaj(i, tauj);
                            pfactor = pfactor*(1-lambdaj(i, tauj));
                        end
                    end
                        if sum(g_phi1_phi{i, tau}) == 0
                            keyboard;
                        end
                    g_phi1_phi{i, tau} = g_phi1_phi{i, tau}/sum(g_phi1_phi{i, tau});
                end
            end
        end

        % ---------------- Estimate tauA ----------------
        for i=1:1:M
            % Use previous segment boundary
            d_now   = d(i, slot_index);
            idx_prv = max(d_now-1, 1);
            bs_prv  = bar_t_star(i, idx_prv);
            for tau = slot_index:-1:bs_prv+1
                idx = slot_index + 1 - tau;
                if idx>=1 && idx<=numel(g_phi1_phi{i, slot_index})
                    % Compute the source-packet timestamp as the probability-weighted mean of
                    % candidate generation slots.
                    tauA_hat(i) = tauA_hat(i) + tau*g_phi1_phi{i, slot_index}(idx);
                end
            end
        end

        tauD_history(:,slot_index) = slot_index-h_history(:,slot_index);
        % Estimate the timestamp of the latest distinct packet received at the base station,
        % separately from destination delivery.
        tauD_hat_new = zeros(M,1);

        % ---------------- Re-estimate downstream tauD[k] when PMF was rebuilt ----------------
        % Recompute packet timestamps separately from feedback reconstruction.
        % If pmf_rebuilt(i)==false -> only recompute the current packet's tauD (k = d_now).
        % If pmf_rebuilt(i)==true  -> recompute tauD for all packets from rebuild_from_pkt(i) to d_now,
        % and then overwrite all history entries prior to the feedback with the ground-truth generation time.
        
        tauD_hat_new = zeros(M,1);  % reset per-source estimate for current Di(t)
        
        for i = 1:M
            d_now = d(i, slot_index);
            if d_now <= 0
                continue;
            end
        
            % decide the starting packet index k_start
            if pmf_rebuilt(i) && rebuild_from_pkt(i) > 0 && rebuild_from_pkt(i) <= d_now
                k_start = rebuild_from_pkt(i);
            else
                k_start = d_now; % only recompute the current Di(t)
            end
        
            % recompute tauD for k = k_start ... d_now
            for k = k_start : d_now
                ts_k   = t_star(i, k);                 % segment start for packet k
                bs_prv = bar_t_star(i, max(k-1, 1));   % previous segment's right end
                val_k  = 0;
        
                if ts_k > 0
                    gvec = g_phi1_phi{i, ts_k};        % PMF anchored at ts_k
                    % MMSE: tauD[k] = sum_{tau=bs_prv+1..ts_k} tau * gvec(ts_k+1 - tau)
                    for tau = ts_k : -1 : (bs_prv)
                        gi = ts_k + 1 - tau;
                        if gi >= 1 && gi <= numel(gvec)
                            val_k = val_k + tau * gvec(gi);
                        end
                    end
                end
        
                % store history for packet k
                tauD_hat_history(i, k) = val_k;
                if k>1
                    if tauD_hat_history(i, k)<tauD_hat_history(i, k-1)
                        keyboard;
                    end
                end
                % expose the value for the "current" Di(t)
                if k == d_now
                    tauD_hat_new(i) = val_k;
                end
            end
        
            % ---------- Set preceding packet timestamps from confirmed feedback ----------
            % If feedback was received this slot for source i, replace tauD_hat_history(i, 1..k_del) with t0
            if pmf_rebuilt(i)
                k_del = rebuild_from_pkt(i);          % packet index confirmed by feedback
                if k_del > 0
                    % ground-truth generation time from delayed AoI feedback at this slot:
                    % The generation timestamp equals the feedback slot minus the destination AoI.
                    t0 = slot_index - Delay - h_history(i, slot_index - Delay);
                    % clamp to [1, K] for safety
                    t0 = max(1, min(t0, K));
                    % overwrite history for all packets up to and including k_del
                    tauD_hat_history(i, 1 : min(k_del, d_now)) = t0;
                end
            end
        end
        % ---------------- Delivery-belief update and mean timestamp ----------------
        % Use (pmf_rebuilt, rebuild_from_pkt),
        % tauD_hat_history, and transmissiontime to compute the mean destination timestamp.
        % With confirmed delivery, zero earlier-packet beliefs and assign the remaining mass
        % to the confirmed packet after computing later-packet beliefs. Otherwise, update the
        % unresolved packet and subsequent packets using their forwarding counts.
        
        for i = 1:M
            % protect indices for the failure-check window
            if slot_index > 2*Delay+1
                % -------- Case A: real feedback this slot for source i --------
                if pmf_rebuilt(i)
                    k_del = rebuild_from_pkt(i);               % packet index just confirmed by feedback
                    if k_del > 0
                        % Zero out beliefs for all earlier packets
                        if k_del > 1
                            belief(i, 1:k_del-1) = 0;
                        end
                
                        % Compute delivery beliefs for packets after k_del:
                        % Each packet belief combines successful delivery of that packet with
                        % unsuccessful delivery of every subsequently observed packet.
                        d_now_i = d(i, slot_index);
                        if k_del + 1 <= d_now_i
                            % Accumulate forwarding attempts for subsequent packets.
                            tail_sum_attempts = 0;
                            for k = d_now_i : -1 : (k_del + 1)
                                % Combine repeated-forwarding failure probabilities with
                                % later-packet outcomes to update delivery beliefs.
                                attempts_k = max(transmissiontime(i, k), 0);
                                % tail_sum_attempts is sum of attempts for packets strictly after k
                                term_future_fail        = (1 - pD(i))^(max(tail_sum_attempts, 0));
                                term_current_fail_block = 1 - (1 - pD(i))^(max(attempts_k, 0));
                                belief(i, k) = term_future_fail * term_current_fail_block;
                
                                % update tail sum for next iteration (moving backward)
                                tail_sum_attempts = tail_sum_attempts + attempts_k;
                            end
                
                            % Then, set the delivered packet's belief to 1 - sum of all later beliefs
                            sum_later_beliefs = sum(belief(i, k_del+1 : d_now_i));
                        else
                            sum_later_beliefs = 0;
                        end
                
                        belief_val = 1 - sum_later_beliefs;
                        belief(i, k_del) = min(1, max(0, belief_val));  % clamp to [0,1]
                    end
               


        
                % -------- Case B: no confirmed delivery --------
                else
                        % Without new confirmation, update beliefs for the unresolved packet and
                        % subsequent packets using forwarding counts.
                        k_fail = rebuild_from_pkt(i)+1;   % packet after the most recently confirmed one
                            attempts = transmissiontime(i, k_fail);
                            % Sum of attempts for all later packets up to the current d_now
                            d_now_i = d(i, slot_index);
                            if k_fail + 1 <= d_now_i
                                latter_attempts = sum(transmissiontime(i, k_fail+1 : d_now_i));
                            else
                                latter_attempts = 0;
                            end
                
                            % Compute the unresolved packet's destination-delivery probability.
                            term_future_fail        = (1 - pD(i))^(max(latter_attempts , 0));
                            term_current_fail_block = 1 - (1 - pD(i))^(max(attempts, 0));
                            belief(i, k_fail) = term_future_fail * term_current_fail_block;
                
                            % Compute subsequent packet beliefs and assign the remaining probability mass.
                            if k_fail +1<= d_now_i
                                % Compute subsequent packet beliefs using suffix forwarding counts.
                                tail_sum_attempts = 0;
                                for k = d_now_i : -1 : (k_fail+1)
                                    attempts_k = max(transmissiontime(i, k), 0);
                                    % tail_sum_attempts is sum of attempts for packets strictly after k
                                    term_future_fail_k        = (1 - pD(i))^(max(tail_sum_attempts , 0));
                                    term_current_fail_block_k = 1 - (1 - pD(i))^(max(attempts_k, 0));
                                    belief(i, k) = term_future_fail_k * term_current_fail_block_k;
    
                                    tail_sum_attempts = tail_sum_attempts + attempts_k;
                                end
                                sum_later_beliefs = sum(belief(i, k_fail : d_now_i));
                            else
                                sum_later_beliefs = sum(belief(i, k_fail));
                            end
                            if k_fail > 1
                                % Assign the residual probability to the preceding packet.
                                belief(i, k_fail-1) = min(1, max(0, 1 - sum_later_beliefs));
                            end
                end
                % -------- Aggregate: tauD_hat_belief(i) = sum_k tauD_hat_history(i,k) * belief(i,k) --------
                d_now = d(i, slot_index);
                if d_now > 0
                    agg = 0;
                    for k = 1:d_now
                        % Average packet timestamp estimates using their destination-delivery
                        % belief weights.
                        agg = agg + tauD_hat_history(i, k) * belief(i, k);
                    end
                    % Feed this belief-weighted aggregate into the next estimator stage
                    % so that subsequent tauD_hat uses belief aggregation.
                    tauD_hat(i) = agg;
                end
            else
                % ---------------- Estimate tauD(t+theta_i) ----------------
                
                    d_now   = d(i, slot_index);
                    idx_now = max(d_now,1);
                    ts      = t_star(i, idx_now);
                    if slot_index - ts <= 2*Delay 
                        if c(i)==1
                            % After a base-station reception, combine the previous destination
                            % estimate and the received-packet estimate using pD.
                            tauD_hat(i)  = tauD_hat_lastslot(i) *(1-pD(i)) + tauD_hat_new(i) * pD(i);
                            c(i)=0;
                        else
                            tauD_hat(i)  = tauD_hat_lastslot(i);
                        end
                    else
                        tauD_hat_new_feedback =  slot_index - h_history(i,slot_index);
                        tauD_hat(i) = tauD_hat_new_feedback;
                    end
            end
        end
        tauD_hat_lastslot = tauD_hat;
        % Convert timestamp estimates to age estimates; delay alignment is applied separately
        % when evaluating errors.
        h_hat = slot_index - tauD_hat;
        z_hat = slot_index - tauA_hat;

        % ---------------- Scheduling (Max-Weight) ----------------
        if set_Policy==1 % Max Weight              
            % Rank sqrt(alpha*pS*pD) times the age reduction and select the first N users.
            [~, sorted_indices] = sort(sqrt(A(1:M).*p(1:M).*pD(1:M)).*(h_hat-z_hat),'descend');
            servenode(:,slot_index) = sorted_indices(1:N);
        end    

        % Accumulate weighted true AoI, then apply the default one-slot increment before
        % delivery-specific updates.
        AoI(:,iteration)=AoI(:,iteration)+A(1:M).*h_history(:,slot_index); 
        h_history(:,slot_index+1)=h_history(:,slot_index)+1;
        d(:,slot_index+1)=d(:,slot_index);

        % ---------------- Transmission / Feedback ----------------
        for i=1:1:N
            % Destination-side reception process
            success_factor(i,slot_index) = rand;
            if slot_index > Delay
                % Process the transmission scheduled Delay slots earlier and update AoI from
                % that packet's source age when delivery conditions hold.
                node_index = servenode(i,slot_index-Delay);
                if (node_index~=(M+1)) && (success_factor(i,slot_index-Delay)<p(node_index)*pD(node_index)) && (d(node_index,slot_index-Delay)>lastdeliveredpackets(node_index))
                    delivered(node_index)=delivered(node_index)+1;     
                    h_history(node_index,slot_index+1)=z(node_index,slot_index-Delay)+Delay+1;
                    D_history(node_index,slot_index+1)=1;
                    lastdeliveredpackets(node_index)=d(node_index,slot_index-Delay+1);
                end
            end

            % BS-side observation process
            % Update base-station observations from uplink reception, distinguishing a new
            % packet from a repeated copy.
            node_index = servenode(i,slot_index);
            if (node_index~=(M+1)) && (success_factor(i,slot_index)<p(node_index)) && (vector_successful_tx(node_index)==0)
                vector_successful_tx(node_index)=1;
                d(node_index,slot_index)=d(node_index,slot_index)+1;
                d(node_index,slot_index+1)=d(node_index,slot_index);
                d_new = d(node_index,slot_index+1);

                % Store reception boundaries for the newly observed packet.
                t_star(node_index, d_new)     = slot_index;               % segment start
                bar_t_star(node_index, d_new) = slot_index;% initialize right end

                transmissiontime(node_index,d_new)=1;
                c(node_index)= 1;

                t_star_D(node_index,d_new)=slot_index;

            elseif (node_index~=(M+1)) && (success_factor(slot_index)<p(node_index))&& (vector_successful_tx(node_index)==1)
                % Segment continues (same packet index)
                d_cur = d(node_index,slot_index);
                bar_t_star(node_index, d_cur) = slot_index;
                transmissiontime(node_index,d_cur)=transmissiontime(node_index,d_cur)+1;
                c(node_index)= 1;
            end

        end
    end

    real_q(:,iteration)=delivered(1:M)/K;

end

% Average across repetitions, scale by T/K, and sum over users. Per-user averaging is left to
% the caller.
AoI_average_GRE=mean(AoI,2); 
optimal_cost_clients=T*AoI_average_GRE(:)/K;
optimal_cost=sum(optimal_cost_clients);
actual_throughput=mean(real_q,2);
end
