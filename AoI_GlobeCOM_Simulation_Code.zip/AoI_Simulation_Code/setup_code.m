function root = setup_code()
% SETUP_CODE Add shared source directories to the MATLAB search path.
%
% Output:
%   root  Absolute path of this package's root directory.
%
% Adds the shared functions and the five figure entry-point directories.
% This function configures paths without starting a simulation.

root = fileparts(mfilename('fullpath'));
addpath(root,'-begin'); % Add the package root to the search path.
folders = {'core/simulations','core/dynamic','core/metrics','core/helpers', ...
           'figures/Figure_1_Runtime','figures/Figure_5_NetSim_vs_MATLAB', ...
           'figures/Figure_6_Arrival_Processes','figures/Figure_8_AoI_Sample_Paths', ...
           'figures/Figure_9_NMSE'};
for k = 1:numel(folders)
    addpath(fullfile(root,folders{k}),'-begin');
end
end
