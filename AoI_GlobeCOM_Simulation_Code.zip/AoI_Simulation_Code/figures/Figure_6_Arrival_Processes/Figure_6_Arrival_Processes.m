% Evaluate weighted AoI across packet-generation intervals.
% Configuration: 40 streams, 2 scheduled per slot, 10000 slots, one run,
% delay 2, destination reliability 0.997, and mean intervals 3:3:30.
% The DynamicChannel functions use mixed periodic/Bernoulli arrivals.
% The NetSim comparison curve is supplied as a stored result array.

clear
clc

global probabilityS probabilityD cost alpha arrival optQ optMU Period prob_index Uniform

tic;

%% Model configuration
M = 40; % Number of streams in the network
N = 2; % Number of maximum scheduled sources in each slot

vector_Period = 1:1:10; % Average arrival time/3
ChannelreliablityS = 1; % Source to BS channel reliability
ChannelreliablityD = 0.997; % BS to destination channel reliability
Delay = 2; % Transmission delay
num_setups = length(vector_Period);
num_iterations = 1; % Independent repetitions per setup
T = 1; % Frame length
h1 = 1; % Initial age
z1 = 0; % Initial system time
prob_index = 1; % Types of arrival processes: 1. Bernoulli arrival 2. Periodic arrival 3. Uniform interarrival time

%% Result storage
optimal_cost_Rand = zeros(1, num_setups);
optimal_cost_LowerBound_stoch = zeros(1, num_setups);
optimal_cost_Max_Weight_estimation_nofeedback = zeros(1, num_setups);

%% Simulation sweep
for count = 1:num_setups
    disp(count)
    K =10000; % Time Horizon

    Period = vector_Period(count) * ones(M, 1)*3;
    cost = zeros(M, 1);
    alpha = [1;2;3;4;5;2;4;6;8;10;15;12;9;6;3;4;8;12;16;20;10;8;6;4;2;5;4;3;2;1;20;16;12;8;4;15;12;9;6;3]; % Priorities for each stream
    arrival = 1 ./ Period; % Arrival rates
    probabilityS = [0.5;0.5;0.23;0.6;0.49;0.5;0.53;0.49;0.47;0.5;0.4;0.52;0.49;0.5;0.5;0.53;0.52;0.5;0.51;0.4;0.53;0.53;0.51;0.51;0.48;0.49;0.46;0.47;0.51;0.52;0.74;0.71;0.52;0.53;0.51;0.51;0.51;0.49;0.66;0.65]; % Source to BS reliability
    probabilityD = ChannelreliablityD * ones(M, 1); % BS to destination reliability
    Uniform = repmat([2*vector_Period(count) 4*vector_Period(count)], M, 1); % Uniform arrival times

    p = probabilityS;
    pD = probabilityD;
    A = alpha;
    Arr = arrival;

    Lower_Bound_find_q(M, N);
    optimal_cost_LowerBound_stoch(count) = sum(alpha .* (1 + 1 ./ optQ + 2 * Delay)) / (2 * M);
    disp('Lower Bound for Stochastic Arrivals')

    randomized_find_optMU(M, N);

    if prob_index == 1
        optimal_cost_Rand(count) = sum(A .* (1 ./ Arr - 1 + 1 ./ optMU ./ p ./ pD + Delay)) / M;
    elseif prob_index == 2
        optimal_cost_Rand(count) = sum(A .* (1 / 2 ./ Arr - 1 + 1 ./ optMU ./ p ./ pD + Delay)) / M;
    elseif prob_index == 3
        optimal_cost_Rand(count) = sum(A .* (29 * vector_Period(count) / 18 - 1 + 1 ./ optMU ./ p ./ pD + Delay)) / M;
    end

    set_Policy = 1;
    [aux, optimal_cost_Max_Weight_estimation_nofeedback(count)] = DynamicChannel_Nofeedback_MW_E_simulation(K, T, M, h1, z1, Delay, num_iterations, set_Policy, N)
    optimal_cost_Max_Weight_estimation_nofeedback(count) = optimal_cost_Max_Weight_estimation_nofeedback(count) / (M * T);
    disp('No-feedback estimation complete')
    toc

    set_Policy = 1;
    [aux, optimal_cost_Max_Weight_estimation_LC(count)] = DynamicChannel_Ave_Nofeedback_MW_E_simulation(K, T, M, h1, z1, Delay, num_iterations, set_Policy, N)
    optimal_cost_Max_Weight_estimation_LC(count) = optimal_cost_Max_Weight_estimation_LC(count) / (M * T);
    disp('LC estimation complete')

    toc
end

%% AoI comparison
vector_Period = 3:3:30;
figure(2)
hold on

plot(vector_Period, optimal_cost_Max_Weight_estimation_nofeedback, 'cv--', 'LineWidth', 3, 'MarkerSize', 10);
plot(vector_Period, optimal_cost_Rand, 'bo-', 'LineWidth', 3, 'MarkerSize', 10);
plot(vector_Period, optimal_cost_LowerBound_stoch, 'k-', 'LineWidth', 3, 'MarkerSize', 2);
bright_orange = [1.00 0.55 0.00];

[Linear_Max_Weight_Estimation_HoLFT_delay_plot_LC] = plot( ...
    vector_Period,  optimal_cost_Max_Weight_estimation_LC, ...
    'p--', 'LineWidth', 3, 'MarkerSize', 10, ...
    'Color', bright_orange, ...
    'MarkerFaceColor', bright_orange, ...
    'MarkerEdgeColor', bright_orange );

[NetSim_Max_Weight_Estimation_HoLFT_delay_plot_LC] = plot( ...
    vector_Period,  [169.2465  182.3985  201.8422  217.6125  233.9730  251.2845  268.4812  279.1665 292.2255  298.1723], ...
    'mx-', 'LineWidth', 3, 'MarkerSize', 10);

xlim([3 30])
ylim([0 150])

