% Compare no-feedback and LC NMSE across arrival parameters and link reliabilities.
% Configuration: 8 streams, 3 scheduled per slot, unit weights, 1000 slots.
% num_mc controls outer runs; num_iterations controls repetitions within each call.
% The uplink and destination base reliabilities use the selected pD value.
% Period=P, Uniform=[5P,6P] with mean 5.5P, and the plotting coordinate is 3P.
% Kernels use Arr=1/Period; the driver also sets global arrival=1/(5P).

clear
clc

global probabilityS probabilityD cost alpha arrival optQ optMU Period prob_index Uniform

tic;

nmse_ylim = [];          % e.g., [0 0.5]; [] means auto
x_xlim    = [];          % e.g., [5 25];  [] means auto

q_low  = 0.10;           % quantile band for shading
q_high = 0.90;

%% Model configuration
M = 8;
N = 3;

vector_Period = 1:1:5;
num_setups = length(vector_Period);

Delay = 1;

ChannelreliablityS = 0.8; %#ok<NASGU>

vector_pD = [0.8, 1.0];
num_pD = length(vector_pD);

num_mc = 1;
num_iterations = 10;

T = 1;
h1 = 1;
z1 = 0;

prob_index = 3;

%% Outer-run NMSE samples
nmse_nf_samples = zeros(num_pD, num_mc, num_setups);
nmse_lc_samples = zeros(num_pD, num_mc, num_setups);

%% Simulation sweep
set_Policy = 1;

for pd_idx = 1:num_pD

    ChannelreliablityD = vector_pD(pd_idx);

    fprintf('Running simulations for pD = %.1f\n', ChannelreliablityD);

    for count = 1:num_setups

        fprintf('  Period setup %d / %d\n', count, num_setups);

        K = 1000;
        cost = zeros(M, 1);

        alpha = [1;1;1;1;1;1;1;1];

        thisPeriod = vector_Period(count);
        Period = ones(M, 1) * thisPeriod;

        arrival = ones(M,1) ./ (5 * Period);

        probabilityS = ones(M, 1) * ChannelreliablityD;
        probabilityD = ones(M, 1) * ChannelreliablityD;

        % Uniform interarrival times span [5P,6P], with mean 5.5P.
        Uniform = repmat([5*thisPeriod 6*thisPeriod], M, 1);

        for r = 1:num_mc

            [nmse_nf, ~] = NMSE_Nofeedback_MW_E_simulation( ...
                K, T, M, h1, z1, Delay, num_iterations, set_Policy, N);

            nmse_nf_samples(pd_idx, r, count) = nmse_nf;

            [nmse_lc, ~] = NMSE_LC_MW_E_simulation( ...
                K, T, M, h1, z1, Delay, num_iterations, set_Policy, N);

            nmse_lc_samples(pd_idx, r, count) = nmse_lc;
        end

        disp('  Done for this Period')
    end
end

%% Means and quantiles across outer runs
x = vector_Period * 3;   % Arrival parameter 3P

nmse_nf_mean = squeeze(mean(nmse_nf_samples, 2));
nmse_lc_mean = squeeze(mean(nmse_lc_samples, 2));

nmse_nf_lo = squeeze(quantile(nmse_nf_samples, q_low, 2));
nmse_nf_hi = squeeze(quantile(nmse_nf_samples, q_high, 2));

nmse_lc_lo = squeeze(quantile(nmse_lc_samples, q_low, 2));
nmse_lc_hi = squeeze(quantile(nmse_lc_samples, q_high, 2));

toc;

%% NMSE curves and quantile bands

figure(2); clf; hold on; box on; grid on;

cols = lines(3);
cols = cols(2:3, :);

estimator_names = { ...
    'MW with No-Feedback Estimation', ...
    'MW with Low-Complexity Estimation'};

plot_handles = gobjects(num_pD, 2);

for pd_idx = 1:num_pD

    pD = vector_pD(pd_idx);

    if abs(pD - 1.0) < 1e-12
        line_style = '-';
    else
        line_style = '--';
    end

    for est_idx = 1:2

        switch est_idx
            case 1
                y_mean = nmse_nf_mean(pd_idx, :);
                y_lo   = nmse_nf_lo(pd_idx, :);
                y_hi   = nmse_nf_hi(pd_idx, :);
                this_color = cols(1, :);

            case 2
                y_mean = nmse_lc_mean(pd_idx, :);
                y_lo   = nmse_lc_lo(pd_idx, :);
                y_hi   = nmse_lc_hi(pd_idx, :);
                this_color = cols(2, :);
        end

        fill([x fliplr(x)], [y_lo fliplr(y_hi)], ...
            this_color, ...
            'FaceAlpha', 0.10, ...
            'EdgeColor', 'none', ...
            'HandleVisibility', 'off');

        plot_handles(pd_idx, est_idx) = plot( ...
            x, y_mean, ...
            line_style, ...
            'Color', this_color, ...
            'LineWidth', 2, ...
            'Marker', 'o', ...
            'MarkerSize', 6);
    end
end

xlabel('Arrival parameter (3P)');
ylabel('NMSE');

title(sprintf('NMSE Comparison under Delay = %d, prob\\_index = %d', ...
    Delay, prob_index));

if ~isempty(nmse_ylim)
    ylim(nmse_ylim);
end

if isempty(x_xlim)
    xlim([min(x) max(x)]);
else
    xlim(x_xlim);
end

legend_handles = gobjects(num_pD * 2, 1);
legend_entries = cell(num_pD * 2, 1);

idx = 1;
for pd_idx = 1:num_pD
    for est_idx = 1:2
        legend_handles(idx) = plot_handles(pd_idx, est_idx);
        legend_entries{idx} = sprintf('p_D = %.1f, %s', ...
            vector_pD(pd_idx), estimator_names{est_idx});
        idx = idx + 1;
    end
end

legend(legend_handles, legend_entries, 'Location', 'NorthEast');
