% Purpose: compare LC-estimated and true AoI sample paths.
% Configuration: 10 streams, 2 scheduled per slot, 1000 slots, forwarding delay 5,
% uniform inter-generation intervals [4,8], and destination reliability 0.8.
% Workflow: obtain estimated/true histories, then plot one stream or the stream mean.
% Matrix rows index streams and columns index slots. The displayed range is
% 200:500. Random draws use the active MATLAB random-number-generator state.

clear; clc;

global probabilityS probabilityD cost alpha Period prob_index Uniform

M = 10;
N = 2;

K = 1000;
T = 1;
Delay = 5;

ChannelreliablityS = 0.5;
ChannelreliablityD = 0.8;

prob_index = 3;
Period = ones(M,1) *6;
Uniform = repmat([4 8], M, 1);

cost  = zeros(M,1);
alpha = [1;2;3;4;5;2;4;6;8;10];

probabilityS = [0.5;0.5;0.23;0.6;0.49;0.5;0.53;0.49;0.47;0.5];
probabilityD = ones(M,1) * ChannelreliablityD;

num_iterations = 1;
set_Policy = 1;

[h_est_hist, h_true_hist, nmse_avg, opt_cost] = LC_AoI_Sample_Path_simulation( ...
    K, T, M, 1, 0, Delay, num_iterations, set_Policy, N);

fprintf("NMSE(avg) = %.6f, opt_cost = %.6f\n", nmse_avg, opt_cost);

%% Plot: choose ONE stream or MEAN over streams
plot_mode = "one";     % "one" or "mean"
stream_id = 1;         % 1..M, only used when plot_mode="one"

t = 1:K;

figure(1); clf; hold on; box on; grid on;

if plot_mode == "one"
    y_est  = h_est_hist(stream_id, :);
    y_true = h_true_hist(stream_id, :);

    p1 = plot(t, y_est,  '-', 'LineWidth', 2);   % estimator: solid
    p2 = plot(t, y_true, '--', 'LineWidth', 2);  % true: dashed

    legend([p1 p2], sprintf('Estimated AoI (stream %d)', stream_id), ...
                   sprintf('True AoI (stream %d)', stream_id), ...
                   'Location','northwest');

else
    % mean across streams (ignore NaN at beginning)
    y_est  = mean(h_est_hist, 1, 'omitnan');
    y_true = mean(h_true_hist, 1, 'omitnan');

    p1 = plot(t, y_est,  '-', 'LineWidth', 2);
    p2 = plot(t, y_true, '--', 'LineWidth', 2);

    legend([p1 p2], 'Estimated AoI (mean over streams)', ...
                   'True AoI (mean over streams)', ...
                   'Location','northwest');
end

xlabel('Slot index');
ylabel('AoI');
title(sprintf('AoI history comparison (Delay=%d)', Delay));
xlim([200 500])

