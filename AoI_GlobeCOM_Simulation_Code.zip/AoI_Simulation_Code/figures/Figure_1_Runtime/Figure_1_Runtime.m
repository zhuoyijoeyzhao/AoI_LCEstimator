% Evaluate scheduler AoI and runtime across user populations.
% Configuration: 5:5:50 users, 3 scheduled per slot, 10000 slots, one run,
% periodic interval 5, uplink reliability 0.5, destination reliability 0.8, delay 5.
% Whole-call timings are in seconds; LC timing is internal cumulative time
% converted to milliseconds per horizon slot.

clear; clc;

global probabilityS probabilityD cost alpha arrival optQ optMU Period prob_index Uniform

%% Model configuration
vector_N = 5:5:50;         % Total number of users in the network (sweep on x-axis)
K_sched  = 3;              % Number of scheduled users per slot
ChannelreliablityS = 0.5;  % Source -> BS reliability p^S
ChannelreliablityD = 0.8;  % BS -> Destination reliability p^D
Delay = 5;                 % Transmission delay (theta)
num_setups = length(vector_N);
num_iterations = 1;       % Number of Monte Carlo runs per setup
T = 1;                     % Frame length
h1 = 1;                    % Initial AoI
z1 = 0;                    % Initial system time
prob_index = 2;            % 1: Bernoulli, 2: Periodic, 3: Uniform inter-arrival
fixedPeriod = 1;

%% Cost and runtime storage
optimal_cost_Rand                              = zeros(1, num_setups);
optimal_cost_LowerBound_stoch                  = zeros(1, num_setups);
optimal_cost_Max_Weight_estimation             = zeros(1, num_setups); % MW-E
optimal_cost_Max_Weight_estimation_nofeedback  = zeros(1, num_setups); % MW-E (no FB)
optimal_cost_Max_Weight_estimation_ave_nofb    = zeros(1, num_setups); % LC-E (Ave_NoFB)

time_Rand                             = zeros(1, num_setups);
time_LB                               = zeros(1, num_setups);
time_MW_E_noFB                        = zeros(1, num_setups);
time_LC_E_ave_noFB                    = zeros(1, num_setups);

%% Simulation sweep
for idx = 1:num_setups
    fprintf('Setup %d / %d\n', idx, num_setups);

    M = vector_N(idx);
    N_sched = K_sched;
    K_horizon = 10000;

    Period       = fixedPeriod * ones(M, 1) * 5;
    cost         = zeros(M, 1);

    alpha        = repmat([1;1;1;1;1;1;1;1], ceil(M/8), 1);
    alpha        = alpha(1:M);
    arrival      = 1 ./ Period;
    probabilityS = ChannelreliablityS * ones(M, 1);
    probabilityD = ChannelreliablityD * ones(M, 1);
    Uniform      = repmat([2*fixedPeriod 4*fixedPeriod], M, 1);

    p   = probabilityS;
    pD  = probabilityD;
    A   = alpha;
    Arr = arrival;

    t0 = tic;
    Lower_Bound_find_q(M, N_sched);
    optimal_cost_LowerBound_stoch(idx) = sum(alpha .* (1 + 1 ./ optQ) + 2 * Delay) / (2 * M);
    time_LB(idx) = toc(t0);

    t0 = tic;
    randomized_find_optMU(M, N_sched);
    switch prob_index
        case 1 % Bernoulli
            optimal_cost_Rand(idx) = sum(A .* (1 ./ Arr - 1 + 1 ./ optMU ./ p ./ pD + Delay)) / M;
        case 2 % Periodic
            optimal_cost_Rand(idx) = sum(A .* (1 / 2 ./ Arr - 1 + 1 ./ optMU ./ p ./ pD + Delay)) / M;
        case 3 % Uniform inter-arrival
            optimal_cost_Rand(idx) = sum(A .* (29 * fixedPeriod / 18 - 1 + 1 ./ optMU ./ p ./ pD + Delay)) / M;
    end
    time_Rand(idx) = toc(t0);

    set_Policy = 1;
    [~, optimal_cost_Max_Weight_estimation(idx)] = MW_E_simulation(...
        K_horizon, T, M, h1, z1, Delay, num_iterations, set_Policy, N_sched);
    optimal_cost_Max_Weight_estimation(idx) = optimal_cost_Max_Weight_estimation(idx) / (M * T);

    set_Policy = 1;
    t0 = tic;
    [~, optimal_cost_Max_Weight_estimation_nofeedback(idx)] = Nofeedback_MW_E_simulation(...
        K_horizon, T, M, h1, z1, Delay, num_iterations, set_Policy, N_sched);
    optimal_cost_Max_Weight_estimation_nofeedback(idx) = optimal_cost_Max_Weight_estimation_nofeedback(idx) / (M * T);
    time_MW_E_noFB(idx) = toc(t0);
    disp('MW with Estimation (No Feedback)');

    set_Policy = 1;

    [est_time_ms, optimal_cost_Max_Weight_estimation_ave_nofb(idx)] = Ave_Nofeedback_MW_E_simulation( K_horizon, T, M, h1, z1, Delay, num_iterations, set_Policy, N_sched);
    optimal_cost_Max_Weight_estimation_ave_nofb(idx) = ...
        optimal_cost_Max_Weight_estimation_ave_nofb(idx) / (M * T);
    time_LC_E_ave_noFB(idx) = mean(est_time_ms)./K_horizon*1000

end

%% Weighted AoI
xAxis = vector_N;
figure(5); clf; hold on; grid on;
plot(xAxis, optimal_cost_Max_Weight_estimation,            'gd-', 'LineWidth', 2.5, 'MarkerSize', 9);   % MW-E
plot(xAxis, optimal_cost_Max_Weight_estimation_nofeedback, 'cv--','LineWidth', 2.5, 'MarkerSize', 9);   % MW-E noFB
plot(xAxis, optimal_cost_Max_Weight_estimation_ave_nofb,   'ks--','LineWidth', 2.5, 'MarkerSize', 9);   % LC-E
plot(xAxis, optimal_cost_Rand,                             'bo-', 'LineWidth', 2.5, 'MarkerSize', 9);   % Randomized
plot(xAxis, optimal_cost_LowerBound_stoch,                 'k-',  'LineWidth', 2.0);                    % LowerBound
legend({'MW-E','MW-E (no FB)','LC-E','Randomized','Lower Bound'}, 'Location', 'Northeast');
ylabel('Expected Weighted Sum AoI');
xlabel('Total number of users (N)');
xlim([min(xAxis) max(xAxis)]);
title(sprintf('K = %d scheduled per slot', K_sched));
hold off;

%% Runtime measurements
figure(6); clf; hold on; grid on;
plot(xAxis, time_MW_E_noFB,     'cv--','LineWidth', 2.5, 'MarkerSize', 9);
plot(xAxis, time_LC_E_ave_noFB, 'ks--','LineWidth', 2.5, 'MarkerSize', 9);
plot(xAxis, time_Rand,          'bo-', 'LineWidth', 2.5, 'MarkerSize', 9);
plot(xAxis, time_LB,            'k-',  'LineWidth', 2.0);

yl = yline(1, 'k--', 'Slot length = 1 ms', ...
    'LineWidth', 1.5, ...
    'LabelHorizontalAlignment', 'right', ...
    'LabelVerticalAlignment',   'top');

legend({'MW-E (no FB)','LC-E','Randomized','Lower Bound'}, 'Location', 'Northwest');
ylabel('Runtime per setup (ms)');
xlabel('Total number of users (N)');
xlim([min(xAxis) max(xAxis)]);

ylim([0,1.4]);
hold off;

