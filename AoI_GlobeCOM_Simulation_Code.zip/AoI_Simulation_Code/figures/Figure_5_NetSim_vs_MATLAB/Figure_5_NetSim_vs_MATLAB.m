% Plot stored MATLAB and NetSim AoI results for mixed periodic/Bernoulli traffic.
% Each result array corresponds to arrival-interval coordinates 3:3:30.
% The displayed horizontal range is 3:21 slots.

clear
clc

vector_Period = 3:3:30;

%% Stored results
optimal_cost_Max_Weight_Full_Knowledge=[271.425 278.267 286.78 293.106 302.28 309.937 315.261 327.932 338.877 352.823]
optimal_cost_Max_Weight_estimation=[163.5,175.853 190.027 202.63 217.857 230.711 245.259 260.299 273.779 287.712]
optimal_cost_Max_Weight_estimation_nofeedback=[166.3061  186.7262  208.5398  232.7572  254.9563  274.6893  298.3496  323.5765  337.3337  364.3398]
optimal_cost_Rand=[287.6622  304.5372  321.4122  338.2872  355.1622  372.0372  388.9122  405.7872  422.6622  439.5372]
optimal_cost_LowerBound_stoch=[31.1899   43.6298   56.0697   68.5096   80.9495   93.3894  102.9475  112.1091  122.1448  132.4885]
optimal_cost_Max_Weight_estimation_LC = [165.7343  188.7996  210.8431  232.8875  251.3902  275.4079  299.3476  320.9225  344.7986  365.2770]

%% Comparison plot
figure(2)
hold on
[optimal_cost_Max_Weight_Full_Knowledge_plot]=plot(vector_Period, optimal_cost_Max_Weight_Full_Knowledge, 'r*-', 'LineWidth', 3, 'MarkerSize', 10);
[optimal_cost_Max_Weight_estimation_plot]= plot(vector_Period, optimal_cost_Max_Weight_estimation, 'gdiamond-', 'LineWidth', 3, 'MarkerSize', 10);
[optimal_cost_Max_Weight_estimation_nofeedback_plot] = plot(vector_Period, optimal_cost_Max_Weight_estimation_nofeedback, 'cv--', 'LineWidth', 3, 'MarkerSize', 10);
[optimal_cost_Rand_plot] = plot(vector_Period, optimal_cost_Rand, 'bo-', 'LineWidth', 3, 'MarkerSize', 10);
[Lower_Bound_plot] = plot(vector_Period, optimal_cost_LowerBound_stoch, 'k-', 'LineWidth', 3, 'MarkerSize', 2);
bright_orange = [1.00 0.55 0.00];

[Linear_Max_Weight_Estimation_HoLFT_delay_plot_LC] = plot( ...
    vector_Period,  optimal_cost_Max_Weight_estimation_LC, ...
    'p--', 'LineWidth', 3, 'MarkerSize', 10, ...
    'Color', bright_orange, ...
    'MarkerFaceColor', bright_orange, ...
    'MarkerEdgeColor', bright_orange );

[NetSim_Max_Weight_Estimation_HoLFT_delay_plot_LC] = plot( ...
    vector_Period,  [181.2465  194.3985  213.8422  229.6125  245.9730  263.2845  280.4812  291.1665  304.2255  310.1723], ...
    'mx-', 'LineWidth', 3, 'MarkerSize', 10);

xlim([3 21])
ylim([0 600])
legend([ optimal_cost_Max_Weight_Full_Knowledge_plot, optimal_cost_Max_Weight_estimation_plot, optimal_cost_Max_Weight_estimation_nofeedback_plot, Linear_Max_Weight_Estimation_HoLFT_delay_plot_LC,NetSim_Max_Weight_Estimation_HoLFT_delay_plot_LC,optimal_cost_Rand_plot,Lower_Bound_plot], ...
      'MW with Full Knowledge', 'MW with Estimation (with feedback delay)', 'MW with No-Feedback Estimation',  'MW with Low-Complexity Estimation', 'MW with Low-Complexity Estimation in NetSim','Randomized','Lower Bound','Location', 'Northeast');

